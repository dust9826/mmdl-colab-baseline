"""Evaluate the recovered 1,000-example LoRA with the archived MMMU runner."""

import base64
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import zipfile


HERE = Path(__file__).resolve().parent if '__file__' in globals() else Path.cwd()
JOB = 'scienceqa-scale-full-20261114'
RUN = JOB + '-evaluation'
COMMIT = 'f1235cf76f1c5637ea61b72a7d36b01c8fbc73a1'
ADAPTER = 'b18e1322813ec31cd9be3cbba9c92572ef3de3cbe5d56a39c4933a3522347ff5'
CAP = 2048
RESULT_FIELDS = (
    'id', 'subject', 'input_sha256', 'actual_engine_prompt_token_ids_sha256', 'seed',
    'status', 'raw_response', 'parsed_answer', 'correct', 'parse_status', 'extraction_status',
    'extraction_rule', 'extraction_evidence', 'finish_reason', 'stop_reason',
    'generated_tokens', 'generation_seconds', 'request_latency_seconds', 'total_sample_seconds',
)
SCORE_FIELDS = ('correct', 'parsed_answer', 'parse_status', 'extraction_rule',
                'extraction_evidence', 'extraction_status')
PACKET_SIZE = 20


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.pending')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def emit(event, payload):
    print('FULL_' + event + ' ' + json.dumps(payload, ensure_ascii=False), flush=True)


def packet(out, name, value):
    """Keep checksummed, small blocks both on disk and in the Colab cell output."""
    data = gzip.compress(json.dumps(value, ensure_ascii=False, separators=(',', ':'),
                                    allow_nan=False).encode(), compresslevel=6, mtime=0)
    directory = out / 'recovery'
    directory.mkdir(exist_ok=True)
    with (directory / f'{name}.json.gz').open('xb') as stream:
        stream.write(data)
    digest = hashlib.sha256(data).hexdigest()
    encoded = base64.b64encode(data).decode()
    chunks = [encoded[i:i + 3600] for i in range(0, len(encoded), 3600)]
    print(f'FULL_PACKET_BEGIN {name} {len(chunks)} {digest}', flush=True)
    for i, chunk in enumerate(chunks):
        print(f'FULL_PACKET_DATA {name} {i} {chunk}', flush=True)
    print(f'FULL_PACKET_END {name}', flush=True)
    return digest


def verify_pair(row, expected):
    for field in ('id', 'subject', 'input_sha256', 'actual_engine_prompt_token_ids_sha256', 'seed'):
        if row[field] != expected[field]:
            raise ValueError(f'{row["id"]}: archived {field} mismatch')
    if row['status'] != 'COMPLETED' or not 0 <= row['generated_tokens'] <= CAP:
        raise ValueError(f'{row["id"]}: invalid generation status or length')


def evaluate(source, repo, out):
    import torch
    from mmdl.evaluation import cli, engine
    from mmdl.evaluation.backends.vllm_backend import VLLMBackend
    from mmdl.evaluation.final_answer_parser_v8 import score_response
    from mmdl.runtime.artifacts import file_records
    from scripts.validate_run import validate
    import colab_runner
    from run_pilot import merge_stage

    conf = read(source / 'config.json')
    expected = {r['id']: r for r in read(source / 'inputs.json')}
    if len(expected) != 900 or set(Counter(r['subject'] for r in expected.values()).values()) != {30}:
        raise ValueError('Invalid 900-question archive')
    for item in conf['code_files']:
        if sha(repo / item['path']) != item['sha256']:
            raise ValueError(f'Baseline code mismatch: {item["path"]}')
    for item in conf['prompts']:
        if sha(repo / item['path']) != item['sha256']:
            raise ValueError(f'Baseline prompt mismatch: {item["path"]}')
    protocol = read(source / 'protocol.json')
    if protocol['generation']['max_new_tokens'] != CAP or protocol['parser'] != 'team-final-answer-v8':
        raise ValueError('Original token limit or parser changed')
    colab_runner.install_budget_2048_protocol()

    paths = read(out / 'setup/locations.json')
    base = Path(paths[protocol['model']['id']]['snapshot'])
    dataset = Path(paths[protocol['dataset']['id']]['data_root'])
    arm = conf.get('training_arm', 'sft')
    job = conf['experiment_id']
    run_id = job + '-evaluation'
    write(out / 'model.json', {'snapshot': str(base)})
    if arm == 'sft':
        adapter = source / 'adapter/adapter_model.safetensors'
        adapter_sha = ADAPTER
        data_sha = conf['training_data_sha256']
        code_sha = conf['training_source_sha256']
        updates = 0
        shutil.copy2(source / 'training.json', out / 'training.json')
        shutil.copytree(adapter.parent, out / 'sft/adapter')
    elif arm == 'dpo':
        training = read(out / 'training.json')
        state = training['arms']['dpo']
        adapter = out / 'dpo/adapter/adapter_model.safetensors'
        adapter_sha = state['adapter_sha256']
        data_sha = sha(out / 'pairs.json')
        code_sha = sha(source / 'run_pilot.py')
        updates = state['updates']
        if (data_sha != training['pair_sha256'] or updates != conf['expected_training_updates']
                or len(set(training['order'])) != conf['expected_training_pairs']
                or not state['reloaded'] or not state['changed_tensors']):
            raise ValueError('DPO training or adapter verification is incomplete')
    else:
        raise ValueError(f'Unsupported evaluation arm: {arm}')
    if sha(adapter) != adapter_sha:
        raise ValueError('Adapter SHA-256 mismatch')
    emit('PHASE', {'stage': 'merge', 'adapter_sha256': adapter_sha, 'new_training_updates': updates})
    merge_stage(source, out, (arm,))
    merged = out / 'merged' / arm
    # The underlying architecture and processor are exactly those of the archived base.
    shutil.copy2(base / 'config.json', merged / 'config.json')
    manifest_path = out / 'merged-model.json'
    write(manifest_path, {
        'kind': 'merged', 'base': {key: protocol['model'][key] for key in ('id', 'revision')},
        'dtype': 'bfloat16',
        'processor_revision': protocol['model']['revision'],
        'train_config_sha256': sha(out / 'training.json'),
        'data_manifest_sha256': data_sha,
        'training_code_sha256': code_sha, 'code_commit': COMMIT,
        'artifact_revision': adapter_sha,
        'files': file_records(merged, sorted(p for p in merged.iterdir() if p.is_file())),
    })
    emit('PHASE', {'stage': 'input_preflight', 'count': 900})
    preflight = colab_runner.preflight(repo, merged, dataset, out / 'input-preflight.json',
                                      source / 'protocol.json')
    if {r['id']: r['input_sha256'] for r in preflight['records']} != {
            key: row['input_sha256'] for key, row in expected.items()}:
        raise ValueError('The 900 processor input hashes differ from the base archive')
    emit('PREFLIGHT_PASS', {'count': preflight['count'], 'max_input_tokens': preflight['max_input_tokens']})

    hardware = read(source / 'hardware.json')
    vram = torch.cuda.get_device_properties(0).total_memory / 2**30
    hardware['expected_vram_gib'] = vram
    hardware['gpu_weight_cap_gib'] = vram - 4
    hardware_path = out / 'hardware.json'
    write(hardware_path, hardware)
    pending = []
    checksums = {}
    writer = engine.RunWriter
    started = time.monotonic()

    def flush():
        if pending:
            name = f'rows-{len(checksums) + 1:03d}'
            checksums[name] = packet(out, name, pending)
            pending.clear()

    class CheckedWriter(writer):
        def save(self, record):
            verify_pair(record, expected[record['id']])
            super().save(record)
            pending.append({key: record.get(key) for key in RESULT_FIELDS})
            if len(pending) >= PACKET_SIZE:
                flush()
                emit('PROGRESS', {'completed': len(self.completed), 'total': 900,
                                  'evaluation_seconds': round(time.monotonic() - started, 1)})

    engine.RunWriter = CheckedWriter
    colab_runner.install_raw_journal(engine, VLLMBackend, out, run_id)
    run_dir = out / 'runs' / run_id
    public = out / 'public'
    sys.argv = [str(HERE / 'run_full.py'), '--protocol', str(source / 'protocol.json'),
                '--hardware', str(hardware_path), '--model-ref', str(manifest_path),
                '--model-path', str(merged), '--base-path', str(base), '--data-root', str(dataset),
                '--artifact-root', str(out), '--public-root', str(public), '--require-commit', COMMIT,
                '--no-download', '--run-id', run_id, '--mode', 'full', '--run-role', 'evaluation', '--job-id', job]
    emit('PHASE', {'stage': 'evaluation', 'batch_size': 2, 'seed_policy': 'per_sample_sha256_v1'})
    try:
        cli.main()
    finally:
        flush()
        write(out / 'packet-index.json', checksums)
    emit('PHASE', {'stage': 'validate_run'})
    audited = validate(run_dir, public / run_id)
    records = [read(path) for path in sorted((run_dir / 'samples').glob('*.json'))]
    if len(records) != 900 or {r['id'] for r in records} != set(expected):
        raise ValueError('Result IDs incomplete or duplicated')
    for row in records:
        verify_pair(row, expected[row['id']])
        score = score_response(row['raw_response'], row['question_type'], row['options'], row['answer'],
                               row['finish_reason'], question=row['question'])
        if any(row[key] != score[key] for key in SCORE_FIELDS):
            raise ValueError(f'Independent V8 mismatch: {row["id"]}')
    summary = read(run_dir / 'summary.json')
    if audited['correct'] != summary['correct']:
        raise ValueError('Validator and final score disagree')
    result = {'summary': summary, 'input_hashes_match': 900, 'actual_prompt_token_hashes_match': 900,
              'validate_run_pass': True, 'direct_v8_matches': 900, 'adapter_sha256': adapter_sha,
              'packet_index': checksums, 'merge': read(out / f'{arm}-merge.json'),
              'backend': read(run_dir / 'backend.json'), 'environment': read(run_dir / 'environment.json'),
              'manifest': read(run_dir / 'run_manifest.json')['identity'],
              'original_engine_defaults': True, 'new_training_updates': updates}
    write(out / 'verified.json', result)
    packet(out, 'verified', result)
    emit('VERIFIED', {'count': 900, 'correct': summary['correct'], 'status': 'COMPLETE'})


def start(payload, payload_sha, *, job=JOB, evaluator='run_full.py',
          runtime_seconds=7.5 * 3600, release_delay=180, wait_for_release=False, trainer=None):
    """Run in a Colab code cell. The only remote inputs are the embedded payload and public snapshots."""
    from collections import deque
    from google.colab import runtime
    import io
    import threading

    root = Path('/content') / job
    root.mkdir(exist_ok=False)
    source, out, repo, env = (root / part for part in ('source', 'results', 'MMDL', 'env'))
    out.mkdir()
    started = stamp()
    begin = time.monotonic()
    deadline = begin + runtime_seconds
    phase = 'bootstrap'
    status = 'FAILED'
    evidence = {}

    def release():
        emit('RELEASE_REQUEST', {'utc': stamp()})
        runtime.unassign()

    def run(label, args, cap=None):
        nonlocal phase
        phase = label
        emit('PHASE', {'stage': phase, 'utc': stamp()})
        remaining = min(deadline - time.monotonic(), cap or float('inf'))
        if remaining <= 0:
            raise TimeoutError(label)
        with (out / f'{label}.log').open('x') as log, subprocess.Popen(
                [str(arg) for arg in args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, errors='replace', start_new_session=True, bufsize=1) as proc:
            def stop():
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)

            timeout = threading.Timer(remaining, stop)
            timeout.daemon = True
            timeout.start()
            tail = deque(maxlen=30)
            try:
                with closing(proc.stdout) as stream:
                    for line in stream:
                        log.write(line)
                        tail.append(line)
                        if line.startswith(('FULL_', 'INPUT_PREFLIGHT ', 'PREF_', 'VERIFIED:')):
                            log.flush()
                            print(line, end='', flush=True)
                if proc.wait() != 0:
                    print(''.join(tail)[-4500:], flush=True)
                    raise RuntimeError(f'{label} exited {proc.returncode}')
            finally:
                timeout.cancel()
                stop()

    watchdog = threading.Timer(runtime_seconds + 300, release)
    watchdog.daemon = True
    watchdog.start()
    try:
        gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=name,driver_version,memory.total',
                                       '--format=csv,noheader'], text=True, timeout=15).strip()
        if '\n' in gpu or 'NVIDIA L4' not in gpu or shutil.disk_usage(root).free < 85 * 2**30:
            raise RuntimeError(f'Need one NVIDIA L4 and 85 GiB free disk: {gpu}')
        evidence['gpu'] = gpu
        emit('GPU', {'device': gpu, 'started_utc': started})
        if hashlib.sha256(payload).hexdigest() != payload_sha:
            raise ValueError('Payload SHA-256 mismatch')
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            if archive.testzip() is not None:
                raise ValueError('Payload CRC mismatch')
            archive.extractall(source)
        del payload
        cache = root / 'hf'
        data_root = root / 'data'
        os.environ.update(HF_HOME=str(cache), MMDL_DATA_ROOT=str(data_root),
                          MMDL_ARTIFACT_ROOT=str(out), TOKENIZERS_PARALLELISM='false',
                          PYTHONUNBUFFERED='1', CUDA_VISIBLE_DEVICES='0')
        for variable in ('VLLM_ENABLE_V1_MULTIPROCESSING', 'VLLM_BATCH_INVARIANT'):
            if variable in os.environ:
                raise RuntimeError(f'Original evaluation requires the default for {variable}')
        run('fetch_repo', ['git', 'clone', '--quiet', 'https://github.com/jang2296/MMDL.git', repo], 300)
        run('pin_repo', ['git', '-C', repo, 'checkout', '--detach', COMMIT], 90)
        run('install_uv', [sys.executable, '-m', 'pip', 'install', '--quiet', 'uv'], 300)
        run('create_environment', ['uv', 'venv', '--python', '3.12.3', env], 600)
        python = env / 'bin/python'
        run('install_pip', ['uv', 'pip', 'install', '--python', python, 'pip==25.2'], 300)
        run('install_pinned_environment', [python, '-m', 'pip', 'install', '--disable-pip-version-check',
            '-r', repo / 'env/requirements-vllm.lock'], 2400)
        run('install_project', ['uv', 'pip', 'install', '--python', python, '--no-deps', '-e', repo], 300)
        os.environ['PYTHONPATH'] = str(repo) + os.pathsep + str(repo / 'src')
        run('verify_environment', [python, '-c',
            "import sys; from importlib.metadata import version; "
            "expected={'vllm':'0.11.0','torch':'2.8.0+cu128','transformers':'4.57.1',"
            "'peft':'0.17.1','pillow':'11.3.0','qwen-vl-utils':'0.0.14'}; "
            "assert sys.version_info[:3]==(3,12,3); "
            "assert {p:version(p) for p in expected}==expected"], 90)
        run('download_pinned_data', [python, '-m', 'mmdl.data.download', '--skip-pro',
                                    '--cache', cache, '--data-root', data_root, '--artifact-root', out], 2700)
        if trainer is not None:
            run('generate_pairs', [python, source / trainer, 'pairs', source, out], 2700)
            run('train_dpo', [python, source / trainer, 'train', source, out], 2700)
        run('evaluate', [python, source / evaluator, source, repo, out])
        if not (out / 'verified.json').is_file():
            raise RuntimeError('Verification output missing')
        status = 'COMPLETE'
    except BaseException as error:
        evidence['error'] = str(error)[:500]
        emit('FAILED', {'stage': phase, 'error': evidence['error']})
        raise
    finally:
        try:
            state = {'status': status, 'stage': phase, 'started_utc': started, 'finished_utc': stamp(),
                     'elapsed_seconds': time.monotonic() - begin, 'payload_sha256': payload_sha,
                     'recovered_packets': len(list((out / 'recovery').glob('rows-*.json.gz'))), **evidence}
            write(out / 'driver.json', state)
            packet(out, 'driver', state)
            target = root / 'recovery.zip'
            with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_STORED) as archive:
                for path in sorted((out / 'recovery').glob('*.json.gz')):
                    archive.write(path, path.name)
                if trainer is not None:
                    for path in sorted((out / 'dpo/adapter').glob('*')):
                        if path.is_file():
                            archive.write(path, 'adapter/' + path.name)
            with zipfile.ZipFile(target) as archive:
                if archive.testzip() is not None:
                    raise IOError('Recovery ZIP CRC mismatch')
            emit('RECOVERY_ZIP', {'bytes': target.stat().st_size, 'sha256': sha(target)})
        finally:
            watchdog.cancel()
            # Allow a short bounded interval for result collection from the live notebook.
            timer = threading.Timer(release_delay, release)
            timer.daemon = not wait_for_release
            timer.start()


if __name__ == '__main__':
    evaluate(*map(Path, sys.argv[1:]))
