"""Train Qwen to finish supported, genuinely length-truncated visual solutions."""

import ast
import base64
from collections import Counter
from hashlib import sha256
from io import BytesIO
import gzip
import json
from math import ceil, isfinite
import os
from pathlib import Path
import random
import re
from statistics import mean
import sys
import textwrap
import time
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
JOB = HERE.name
NOTEBOOK = 'QWEN_LEARNED_FINISH_2048_L4_20261117_R2.ipynb'
CAP, BOUNDARY, BATCH, WINDOW, CONTEXT = 2048, 1920, 8, 24, 12288
MIN_LATE, TARGET_LATE, CANDIDATES, DEVELOPMENT = 12, 48, 48, 6
EPOCHS, ACCUMULATION, RANK, LR = 2, 4, 8, 5e-5
TRAIN_PIXELS = {'shortest_edge': 65536, 'longest_edge': 1003520}
FAMILIES = {
    'stock': ('Units, rejected', 'Subtract rejected units from units received in every row.',
              'net accepted units', 'units'),
    'invoice': ('Quantity, price, credit', 'Multiply quantity by price, then subtract the credit in every row.',
                'net invoice value in credits', 'credits'),
    'energy': ('Power kW, hours', 'Multiply power by hours in every row.',
               'total energy in kWh', 'kWh'),
    'moment': ('Force N, arm m', 'Multiply signed force by arm length in every row and retain the sign.',
               'net signed moment in N·m', 'N·m'),
}
GROUPS = ('Aster', 'Birch', 'Cedar', 'Dahlia', 'Elm', 'Fir', 'Hazel', 'Iris',
          'Juniper', 'Larch', 'Maple', 'Oak')
ARMS = ('base2048', 'cue2048', 'sft2048')
ROW_FIELDS = ('correct', 'parse_status', 'parsed_answer', 'generated_tokens', 'finish_reason', 'route')
NUMBER = r'[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.0+)?'
CHECK_LINE = re.compile(
    r'^(?:\d+[.)]\s*)?(?:(?:panel|group)\s+)?(' + '|'.join(GROUPS)
    + r')(?:\s+(?:subtotal|total|check|net|contribution|energy|moment|value|sum))*\s*[:=|]\s*(.*?)\s*$',
    re.I)


def json_bytes(obj):
    return json.dumps(obj, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()


def digest(data):
    return sha256(data).hexdigest()


def write(path, obj):
    path.write_bytes(json_bytes(obj) + b'\n')


def seed(tag):
    return int(digest(f'3407:{tag}'.encode())[:16], 16)


def task_formula(family, values):
    a, b, *rest = values
    if family == 'stock':
        return a - b
    if family == 'invoice':
        return a * b - rest[0]
    return a * b


def synthetic(family, index, development=False):
    from PIL import Image, ImageDraw, ImageFont

    sid = f"completion-synthetic-{'dev' if development else 'train'}-r2-{family}-{index:03d}"
    rng = random.Random(seed(sid))
    labels = GROUPS[:10 + index % 3]
    size = (1140, 1256)
    image = Image.new('RGB', size, '#f7f1e5' if development else 'white')
    draw = ImageDraw.Draw(image)
    font_path = Path('/System/Library/Fonts/Supplemental') / ('Verdana.ttf' if development else 'Arial.ttf')
    head, body = (ImageFont.truetype(str(font_path), n) for n in (33, 28))
    names, rule, requested, units = FAMILIES[family]
    header = ('Warehouse inspection', 'Invoice reconciliation', 'Equipment run log', 'Force and arm log')
    draw.text((30, 23), header[list(FAMILIES).index(family)], font=head, fill='#152941')
    draw.text((30, 69), f'Source columns: {names} · Reference subtotal on each card', font=body, fill='#152941')
    generated_rows, totals = {}, {}
    for group_index, group in enumerate(labels):
        x, y = 28 + 280 * (group_index % 4), 130 + 365 * (group_index // 4)
        draw.rectangle((x, y, x + 246, y + 338), fill='#e6eef4', outline='#315271', width=2)
        draw.text((x + 13, y + 9), group, font=head, fill='#152941')
        values = []
        for row_index in range(7 + index % 2):
            if family == 'stock':
                row = (rng.randint(11, 37), rng.randint(1, 9))
            elif family == 'invoice':
                row = (rng.randint(3, 12), rng.randint(3, 15), rng.randint(1, 7))
            elif family == 'energy':
                row = (rng.randint(4, 19), rng.randint(2, 13))
            else:
                row = (rng.randint(6, 21) * (-1 if rng.random() < .35 else 1), rng.randint(2, 9))
            values.append(row)
            for col, val in enumerate(row):
                draw.text((x + 29 + col * 72, y + 65 + row_index * 30), str(val), font=body,
                          fill='#152941', anchor='mm')
        generated_rows[group] = values
        totals[group] = sum(task_formula(family, row) for row in values)
        draw.line((x + 10, y + 291, x + 236, y + 291), fill='#315271', width=2)
        draw.text((x + 13, y + 299), f'Subtotal: {totals[group]}', font=body, fill='#152941')
    value = sum(totals.values())
    if len(set(totals.values())) != len(totals) or value in totals.values():
        return None
    question = f'What is the {requested} across all {len(labels)} groups in the visual record?'
    prompt = (f'Question: {question}\n{rule} Sum the group subtotals for the requested result. '
              'First transcribe the printed reference subtotal for each group in a table with columns Group and Subtotal. '
              'Audit those reference values with the original rows. Show a separate expression and running subtotal '
              'for each row you verify, and conclude with the overall answer once you have sufficient evidence.')
    row = {'id': sid, 'family': family, 'split': 'development' if development else 'train',
           'question': question, 'prompt': prompt, 'answer': str(value), 'units': units,
           'group_subtotals': totals, 'original_values': generated_rows}
    return row, image


def unpack(path):
    code = ''.join(next(c['source'] for c in json.loads(path.read_bytes())['cells'] if c['id'] == 'run'))
    constants = {node.targets[0].id: node.value for node in ast.parse(code).body
                 if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}
    data = base64.b64decode(ast.literal_eval(constants['PAYLOAD']), validate=True)
    if digest(data) != ast.literal_eval(constants['PAYLOAD_SHA']):
        raise ValueError(f'Notebook payload hash mismatch: {path}')
    return ZipFile(BytesIO(data))


def build():
    from concurrent.futures import ThreadPoolExecutor
    from PIL import Image

    sys.path.insert(0, str(HERE.parent / 'verified-dpo60-20261115'))
    from experiment import grams, image_signature
    sys.path.insert(0, str(HERE.parent / 'verified-preference-20261112'))
    from build_colab import BASELINE, normalize, rgb_digest

    prior = HERE.parent / 'single-call-finish-20261117' / 'QWEN_SINGLE_CALL_2048_4096_L4_20261117.ipynb'
    with unpack(prior) as archived:
        files = {name: archived.read(name) for name in archived.namelist() if name != 'audit.json'}
        identity = json.loads(archived.read('audit.json'))
    rows = json.loads(files['mmmu.json'])
    refs = {normalize(row['question']): row['id'] for row in rows}
    ref_text = [(t, grams(t)) for t in refs if len(t) >= 32]
    paths = sorted({BASELINE / item['image'] for row in rows for m in row['messages']
                    for item in m['content'] if item['type'] == 'image'})

    def reference(path):
        if digest(path.read_bytes()) != path.stem:
            raise ValueError(f'Archived evaluation image changed: {path.name}')
        with Image.open(path) as im:
            return rgb_digest(im), image_signature(im)

    with ThreadPoolExecutor(max_workers=8) as pool:
        ref_images = list(pool.map(reference, paths))
    ref_pixels = {value for value, _ in ref_images}
    exclusions = Counter()
    seen = set()
    for development, count in ((False, CANDIDATES), (True, DEVELOPMENT)):
        name = 'development' if development else 'training'
        examples = []
        for family in FAMILIES:
            kept = 0
            for index in range(count * 3):
                task = synthetic(family, index, development=development)
                if task is None:
                    exclusions['degenerate_synthetic_values'] += 1
                    continue
                row, image = task
                rgb = rgb_digest(image)
                mark, aspect = image_signature(image)
                question = normalize(row['question'])
                signature = grams(question)
                near_text = any(0.88 <= len(t)/len(question) <= 1.14
                                and 2*len(g & signature) >= .92*(len(g)+len(signature)) for t, g in ref_text)
                near_image = any(.94 <= aspect/ratio <= 1.07 and (mark ^ sig).bit_count() <= 4
                                 for _, (sig, ratio) in ref_images)
                if question in refs or near_text or near_image or rgb in ref_pixels or rgb in seen:
                    exclusions['overlap'] += 1
                    continue
                seen.add(rgb)
                with BytesIO() as stream:
                    image.save(stream, 'WEBP', lossless=True, method=2)
                    files[f"{name}/train-images/{row['id']}.webp"] = stream.getvalue()
                examples.append(row | {'image_rgb_sha256': rgb})
                kept += 1
                if kept == count:
                    break
            if kept != count:
                raise ValueError(f'{name} {family}: insufficient nonoverlapping examples')
        examples.sort(key=lambda row: seed('candidate:' + row['id']))
        files[f'{name}/candidates.json'] = json_bytes(examples)
        files[f'{name}/model-settings.json'] = json_bytes(json.loads(files['protocol.json'])['generation'])
    files['finish_sft.py'] = (HERE / 'experiment.py').read_bytes()
    audit = {'evaluation_ids': identity['ids'], 'engineering_subjects': identity['engineering_subjects'],
             'validation_images': len(paths), 'validation_questions': len(rows),
             'training_candidates': len(FAMILIES) * CANDIDATES, 'development_count': len(FAMILIES) * DEVELOPMENT,
             'overlap_after_exclusion': 0, 'exclusions': exclusions,
             'overlap_rules': 'Normalized question exact or trigram Dice >=0.92; exact image RGB or dHash <=4 with similar aspect.',
             'training_data_source': 'Independent seeded arithmetic tables in four families, with printed reference subtotals and row audit prompts.',
             'digests': {name: digest(data) for name, data in files.items()}}
    if len(set(audit['evaluation_ids'])) != 900 or [row['id'] for row in rows] != audit['evaluation_ids']:
        raise ValueError('Expected frozen evaluation with 900 identifiers')
    files['audit.json'] = json_bytes(audit)
    with BytesIO() as stream:
        with ZipFile(stream, 'w') as archive:
            for name, data in sorted(files.items()):
                if name.endswith('.py'):
                    compile(data, name, 'exec')
                archive.writestr(ZipInfo(name), data, compress_type=ZIP_DEFLATED, compresslevel=6)
        payload = stream.getvalue()
    driver = files['run_full.py'].decode().split("\nif __name__ == '__main__':", 1)[0]
    old = "        run('evaluate', [python, source / evaluator, source, repo, out])"
    if driver.count(old) != 1:
        raise ValueError('Unexpected pinned Colab driver')
    driver = driver.replace(old, """        for step in ('preflight', 'collect', 'train', 'merge', 'development', 'eval-base', 'eval-sft', 'compare'):
            run(step, [python, source / evaluator, step, source, repo, out])""")
    driver = driver.replace("if trainer is not None:\n                    for path in sorted((out / 'dpo/adapter').glob('*')):",
                            "if (out / 'sft/adapter').is_dir():\n                    for path in sorted((out / 'sft/adapter').glob('*')):")
    lines = ''.join(f'    {part!r}\n' for part in textwrap.wrap(base64.b64encode(payload).decode(), 180))
    main = (f'# @title L4 · 검산한 마무리 LoRA와 2048토큰 세 조건\n'
            f'PAYLOAD_SHA = {digest(payload)!r}\nPAYLOAD = (\n{lines})\n{driver}\n'
            f'start(base64.b64decode(PAYLOAD, validate=True), PAYLOAD_SHA, job={JOB!r}, '
            "evaluator='finish_sft.py', runtime_seconds=9.5*3600, release_delay=240)\n")
    recovery = ('# @title 결과 및 LoRA ZIP 다운로드\nfrom google.colab import files\n'
                f'files.download("/content/{JOB}/recovery.zip")\n')
    intro = ('# Qwen3-VL · 답을 쓰고 끝내는 동작 학습\n\n'
             '학습 자료는 별도 합성 이미지 문제다. MMMU 900문항은 평가에 쓰며 질문과 이미지는 중복 검사에 사용한다. '
             '실제 2048토큰에서 잘린 초안 가운데 원본 도표의 중간 합계를 검산할 수 있는 초안에만 '
             '정답과 종료를 붙인다. LoRA는 마무리 토큰만 맞히도록 학습한다.\n\n'
             '원본 자유 생성, 원본에 답 머리말을 넣는 생성, 학습 모델 자유 생성은 동일 P0·2048·V8로 비교한다. '
             '학습이나 평가에서 오류가 나면 확보한 근거를 보존하고 GPU 해제를 요청한다.\n')
    cells = [{'cell_type': 'markdown', 'id': 'intro', 'metadata': {}, 'source': intro.splitlines(True)}]
    for cell_id, code in (('run', main), ('download', recovery)):
        compile(code, NOTEBOOK, 'exec')
        cells.append({'cell_type': 'code', 'id': cell_id, 'metadata': {'cellView': 'form'},
                      'source': code.splitlines(True), 'execution_count': None, 'outputs': []})
    write(HERE / NOTEBOOK, {'nbformat': 4, 'nbformat_minor': 5, 'cells': cells,
                            'metadata': {'accelerator': 'GPU', 'colab': {'gpuType': 'L4'},
                                         'kernelspec': {'name': 'python3', 'display_name': 'Python 3'}}})
    print(json.dumps({'notebook': NOTEBOOK, 'bytes': len(payload), 'sha256': digest(payload),
                      'training_candidates': audit['training_candidates'], 'development': audit['development_count'],
                      'mmmu_questions': len(rows), 'mmmu_images': len(paths), 'excluded': exclusions}))


def subtotal_checks(text, expected):
    """Check explicit labeled subtotals from the draft against independently solved values."""
    seen = {}
    for original in text.splitlines():
        cleaned = re.sub(r'\\(?:text|mathrm|mathbf)\{([^{}]+)\}', r'\1', original)
        cleaned = re.sub(r'\\(?:boxed)\{([^{}]+)\}', r'\1', cleaned)
        for char in ('$', '*', chr(96), '&', r'\(', r'\)', r'\[', r'\]'):
            cleaned = cleaned.replace(char, '')
        cleaned = cleaned.replace('−', '-').strip(' -|#>_')
        match = CHECK_LINE.fullmatch(cleaned)
        if not match:
            continue
        name, result = match[1].capitalize(), match[2]
        if name not in expected:
            continue
        # A table's final numeric column, an equality, or a labeled bare scalar.
        result = re.split(r'[=|]', result.rstrip(' |'))[-1].strip()
        parsed = re.fullmatch(r'(' + NUMBER + r')(?:\s+(?:units?|credits?|kWh|N[· ]m))?[\s.,;]*', result, re.I)
        if parsed:
            value = int(parsed[1].replace(',', '').split('.')[0])
            seen[name] = {'value': value, 'line': original.strip()[:200]}
    return seen


def ending(row, text):
    from mmdl.evaluation.final_answer_parser_v8 import score_response
    return score_response(text, 'open', [], row['answer'], 'stop', question=row['question'])


def choose_target(row, token_ids, tokenizer):
    from experiment import decode, has_explicit_answer

    expected = row['group_subtotals']
    recomputed = {name: sum(task_formula(row['family'], field) for field in values)
                  for name, values in row['original_values'].items()}
    if expected != recomputed or sum(recomputed.values()) != int(row['answer']):
        raise ValueError(f"Independent proof mismatch: {row['id']}")
    if has_explicit_answer(decode(tokenizer, token_ids), 'open', [], row['question']):
        return None
    outcome = ' + '.join(f'({value})' if value < 0 else str(value) for value in expected.values())
    tail = f"\n\nThe verified group subtotals sum to {outcome} = {row['answer']} {row['units']}.\nFinal answer: {row['answer']}"
    tail_tokens = tokenizer.encode(tail, add_special_tokens=False) + [tokenizer.eos_token_id]
    if not ending(row, tail)['correct'] or not 0 < len(tail_tokens) <= 128:
        raise ValueError(f"V8 could not verify the final target: {row['id']}")
    text = decode(tokenizer, token_ids[:BOUNDARY])
    line_end = [m.start() for m in re.finditer('\n', text)]
    # Keep a genuinely generated prefix and don't cut a line or add a new user turn.
    for offset in reversed(line_end):
        prefix = text[:offset].rstrip()
        if len(prefix) < 1300:
            break
        checks = subtotal_checks(prefix, expected)
        if {name: value['value'] for name, value in checks.items()} != expected:
            continue
        ids = tokenizer.encode(prefix, add_special_tokens=False)
        if (len(ids) < 512 or len(ids) > BOUNDARY or ids != token_ids[:len(ids)]
                or decode(tokenizer, ids + tail_tokens) != prefix + tail):
            continue
        return {'draft_ids': ids, 'tail_ids': tail_tokens, 'prefix_tokens': len(ids),
                'supervised_tokens': len(tail_tokens), 'tail': tail, 'checks': checks,
                'draft_end': prefix[-600:], 'draft_token_sha256': digest(json_bytes(token_ids))}
    return None


def preflight(source, repo, out):
    from run_full import emit, packet, read, sha

    audit = read(source / 'audit.json')
    for name, expected in audit['digests'].items():
        if sha(source / name) != expected:
            raise ValueError(f'Frozen input differs: {name}')
    scorer = read(source / 'scorer_source.json')
    for item in scorer['files']:
        if sha(repo / item['path']) != item['sha256']:
            raise ValueError('Frozen V8 parser source changed')
    sealed = read(source / 'mmmu.json')
    train, dev = (read(source / folder / 'candidates.json') for folder in ('training', 'development'))
    groups = (train, dev, sealed)
    counts = (audit['training_candidates'], audit['development_count'], 900)
    if any(len({row['id'] for row in group}) != n for n, group in zip(counts, groups, strict=True)):
        raise ValueError('Candidate or evaluation scope mismatch')
    if len({row['id'] for group in groups for row in group}) != sum(counts):
        raise ValueError('Train, development and MMMU IDs must be disjoint')
    if (audit['overlap_after_exclusion'] != 0 or audit['evaluation_ids'] != [row['id'] for row in sealed]
            or len({row['image_rgb_sha256'] for row in train + dev}) != len(train + dev)
            or any(not row['id'].startswith('completion-synthetic-train-') for row in train)
            or any(not row['id'].startswith('completion-synthetic-dev-') for row in dev)):
        raise ValueError('Unexpected training data provenance')
    public = {k: v for k, v in audit.items() if k not in ('evaluation_ids', 'digests')}
    write(out / 'data-audit.json', public)
    packet(out, 'data-audit', public)
    emit('DATA_FROZEN', public)


def snapshot(out):
    import run_pilot as pilot
    from run_full import read

    path = Path(read(out / 'setup/locations.json')[pilot.MODEL]['snapshot'])
    if path.name != pilot.REVISION:
        raise ValueError('Expected the original pinned Qwen checkpoint')
    return path


def candidate_prompts(processor, folder, rows):
    import run_pilot as pilot

    prompts = []
    for row in rows:
        prompt, image = pilot.train_input(processor, folder, row)
        prompts.append({'prompt': prompt, 'multi_modal_data': {'image': image}})
    return prompts


def collect(folder, out):
    from mmdl.evaluation.final_answer_parser_v8 import score_response
    from mmdl.runtime.contracts import sample_seed
    from transformers import AutoProcessor
    from experiment import decode
    from run import request_settings
    from run_full import emit, packet, read
    import run_pilot as pilot

    path = snapshot(out)
    write(out / 'model.json', {'snapshot': str(path), 'id': pilot.MODEL, 'revision': pilot.REVISION})
    processor = AutoProcessor.from_pretrained(path, local_files_only=True, use_fast=True)
    processor.image_processor.size = TRAIN_PIXELS
    generation = {'generation': read(folder / 'model-settings.json')}
    candidates = read(folder / 'candidates.json')
    if len(candidates) != CANDIDATES * len(FAMILIES) or any(row['split'] != 'train' for row in candidates):
        raise ValueError('Only the audited independent candidate bank may enter collection')
    llm = pilot.engine(path, {'size': TRAIN_PIXELS}, BATCH, CONTEXT, 1)
    checked, stats, families = [], Counter(), Counter()
    started = time.monotonic()
    attempts_file = out / 'collection.jsonl'
    for offset in range(0, len(candidates), BATCH):
        batch = candidates[offset:offset + BATCH]
        params = [request_settings(generation, sample_seed(pilot.SEED, row['id']), CAP) for row in batch]
        results = llm.generate(candidate_prompts(processor, folder, batch), params, use_tqdm=False)
        for row, output in zip(batch, results, strict=True):
            result, = output.outputs
            ids = list(result.token_ids)
            if not output.finished or not 0 < len(ids) <= CAP or not output.prompt_token_ids:
                raise ValueError(f"Malformed generated draft: {row['id']}")
            status = 'already_stopped'
            grade = score_response(result.text, 'open', [], row['answer'], result.finish_reason, question=row['question'])
            if result.finish_reason == 'length' and len(ids) == CAP:
                status = 'cap_without_verified_subtotals'
                chosen = choose_target(row, ids, processor.tokenizer)
                if chosen is not None:
                    status = 'verified_suffix'
                    reconstructed = decode(processor.tokenizer, chosen['draft_ids'] + chosen['tail_ids'])
                    if not ending(row, reconstructed)['correct']:
                        raise ValueError(f"Checked continuation failed V8: {row['id']}")
                    record = row | chosen | {'draft_finish_reason': result.finish_reason, 'draft_tokens': len(ids),
                                             'base_parse_status': grade['parse_status'], 'base_correct': grade['correct'],
                                             'prompt_token_sha256': digest(json_bytes(list(output.prompt_token_ids)))}
                    checked.append(record)
                    families[row['family']] += 1
            stats[status] += 1
            pilot.append(attempts_file, {'id': row['id'], 'family': row['family'], 'status': status,
                                       'tokens': len(ids), 'correct': grade['correct'],
                                       'parse_status': grade['parse_status'], 'finish_reason': result.finish_reason,
                                       'last_text': result.text[-500:] if status.startswith('cap') else None})
        emit('COLLECT_PROGRESS', {'attempted': sum(stats.values()), 'eligible': len(checked), 'target': TARGET_LATE,
                                  'counts': stats, 'by_family': families, 'seconds': time.monotonic() - started})
        if len(checked) >= TARGET_LATE:
            break
    selected = checked[:TARGET_LATE]
    counts = Counter(row['family'] for row in selected)
    report = {'attempted': sum(stats.values()), 'counts': stats, 'selected': len(selected), 'by_family': counts,
              'eligible_base_missed': sum(not row['base_correct'] for row in selected), 'cap': CAP,
              'min': MIN_LATE, 'target': TARGET_LATE, 'seconds': time.monotonic() - started,
              'mean_prefix_tokens': mean(row['prefix_tokens'] for row in selected) if selected else None,
              'mean_target_tokens': mean(row['supervised_tokens'] for row in selected) if selected else None,
              'collection_manifest_sha256': digest(json_bytes(selected) + b'\n')}
    packet(out, 'collection', report)
    packet(out, 'collection-attempts', pilot.rows(attempts_file))
    for i in range(0, len(selected), 6):
        packet(out, f'train-rows-{1 + i//6:02d}', selected[i:i+6])
    if not MIN_LATE <= len(selected) or len(counts) < 2:
        raise ValueError(f'Only {len(selected)} independently supported late drafts in {len(counts)} families')
    write(out / 'train.json', selected)
    emit('COLLECT_COMPLETE', report)


def train(folder, out):
    import torch
    from peft import LoraConfig, get_peft_model, get_peft_model_state_dict
    from peft.utils.save_and_load import load_peft_weights
    from transformers import AutoProcessor, Qwen3VLForConditionalGeneration
    from run_full import emit, packet, read, sha
    import run_pilot as pilot

    started = time.monotonic()
    torch.manual_seed(pilot.SEED)
    path = snapshot(out)
    processor = AutoProcessor.from_pretrained(path, local_files_only=True, use_fast=True)
    processor.image_processor.size = TRAIN_PIXELS
    base = Qwen3VLForConditionalGeneration.from_pretrained(path, local_files_only=True,
              dtype=torch.bfloat16, attn_implementation='sdpa', device_map={'': 'cuda:0'})
    names = [name for name, module in base.named_modules() if isinstance(module, torch.nn.Linear)
             and '.language_model.layers.' in name and name.rsplit('.', 1)[-1] in ('q_proj', 'v_proj')]
    if len(names) != 2 * base.config.text_config.num_hidden_layers:
        raise ValueError('Unexpected decoder LoRA target modules')
    model = get_peft_model(base, LoraConfig(r=RANK, lora_alpha=2 * RANK, lora_dropout=0.0, bias='none',
                                          target_modules=names, task_type='CAUSAL_LM'))
    params = [p for name, p in model.named_parameters() if p.requires_grad and 'lora_' in name]
    if not params or len(params) != sum(p.requires_grad for p in model.parameters()):
        raise ValueError('Only adapters may be trainable')
    initial = {k: v.detach().cpu().clone() for k, v in get_peft_model_state_dict(model).items()}
    if any(v.count_nonzero() for k, v in initial.items() if 'lora_B' in k):
        raise ValueError('Expected zero initial LoRA residual')
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
    model.enable_input_require_grads()
    selected = read(out / 'train.json')
    audited = {row['id']: row for row in read(folder / 'candidates.json')}
    contexts = {}
    eos = processor.tokenizer.eos_token_id
    for row in selected:
        source = audited[row['id']]
        if any(row[key] != source[key] for key in source):
            raise ValueError(f"Training item differs from independent source: {row['id']}")
        prompt, image = pilot.train_input(processor, folder, row)
        batch = processor(text=[prompt], images=[image], return_tensors='pt')
        draft, target = row['draft_ids'], row['tail_ids']
        if (digest(json_bytes(batch['input_ids'][0].tolist())) != row['prompt_token_sha256']
                or row['draft_finish_reason'] != 'length' or row['draft_tokens'] != CAP
                or not 512 <= len(draft) <= BOUNDARY or not 0 < len(target) <= 128 or target[-1] != eos
                or len(draft) + len(target) > CAP):
            raise ValueError(f"Prompt or masked completion audit failed: {row['id']}")
        history = torch.tensor([draft], dtype=batch['input_ids'].dtype)
        batch['input_ids'] = torch.cat((batch['input_ids'], history), dim=-1)
        batch['attention_mask'] = torch.cat((batch['attention_mask'], torch.ones_like(history)), dim=-1)
        for key in ('token_type_ids', 'mm_token_type_ids'):
            if key in batch:
                batch[key] = torch.cat((batch[key], torch.zeros_like(history)), dim=-1)
        contexts[row['id']] = (batch, target)
    if len(contexts) != len(selected) or len(contexts) < MIN_LATE:
        raise ValueError('Unexpected training examples')
    optimizer = torch.optim.AdamW(params, lr=LR, weight_decay=0.0)
    records, orders = [], []
    supervised_tokens = 0
    train_start = time.monotonic()
    model.train()
    torch.cuda.reset_peak_memory_stats()
    emit('TRAIN_READY', {'examples': len(selected), 'epochs': EPOCHS, 'updates': ceil(len(selected)/ACCUMULATION)*EPOCHS})
    for epoch in range(EPOCHS):
        order = list(contexts)
        random.Random(pilot.SEED + epoch).shuffle(order)
        orders.append(order)
        for offset in range(0, len(order), ACCUMULATION):
            group = order[offset:offset + ACCUMULATION]
            optimizer.zero_grad(set_to_none=True)
            values = []
            for sid in group:
                cpu, target = contexts[sid]
                gpu = {k: tensor.to('cuda:0') for k, tensor in cpu.items()}
                # completion_logp selects exactly the logits that predict the passed tail.
                loss = -pilot.completion_logp(model, base, gpu, target).mean()
                (loss / len(group)).backward()
                values.append(float(loss.detach()))
                supervised_tokens += len(target)
            norm = float(torch.nn.utils.clip_grad_norm_(params, 1.0, error_if_nonfinite=True))
            optimizer.step()
            step = {'step': len(records) + 1, 'epoch': epoch + 1, 'examples': len(group),
                    'loss': mean(values), 'gradient_norm': norm}
            if not isfinite(step['loss']) or not isfinite(norm):
                raise ValueError('Nonfinite training statistics')
            records.append(step)
            emit('TRAIN_UPDATE', step | {'seconds': time.monotonic() - train_start})
    folder = out / 'sft' / 'adapter'
    model.save_pretrained(folder, safe_serialization=True)
    final = {name: tensor.detach().cpu() for name, tensor in get_peft_model_state_dict(model).items()}
    loaded = load_peft_weights(folder, device='cpu')
    if set(final) != set(loaded) or any(not torch.equal(tensor, loaded[name]) for name, tensor in final.items()):
        raise ValueError('LoRA disk reload differs from trained tensors')
    changed = sum(not torch.equal(tensor, initial[name]) for name, tensor in final.items())
    if not changed or any(not bool(tensor.isfinite().all()) for tensor in final.values()):
        raise ValueError('No finite learned adapter change')
    if (supervised_tokens != EPOCHS * sum(row['supervised_tokens'] for row in selected)
            or sum(r['examples'] for r in records) != EPOCHS * len(selected)):
        raise ValueError('Masked target or training example counts differ')
    arm = {'updates': len(records), 'reloaded': True, 'changed_tensors': changed,
           'adapter_sha256': sha(folder / 'adapter_model.safetensors'), 'supervised_tokens': supervised_tokens,
           'peak_cuda_gib': torch.cuda.max_memory_allocated() / 2**30}
    report = {'seed': pilot.SEED, 'epochs': EPOCHS, 'rank': RANK, 'lr': LR, 'accumulation': ACCUMULATION,
              'train_sha256': sha(out / 'train.json'), 'examples': len(selected), 'target_modules': names,
              'loss': 'cross entropy on verified continuation plus EOS; prompt and entire draft masked',
              'training_prompt_hash_matches': len(contexts), 'epoch_orders': orders, 'steps': records,
              'arms': {'sft': arm}, 'seconds': time.monotonic() - started}
    write(out / 'training.json', report)
    packet(out, 'training', report)
    emit('TRAIN_COMPLETE', arm | {'examples': len(selected), 'seconds': report['seconds']})


def eval_inputs(source, out, folder, path):
    from transformers import AutoConfig, AutoProcessor
    from run import mmmu_prompts
    from run_full import read

    processor = AutoProcessor.from_pretrained(path, local_files_only=True, use_fast=True)
    if folder is not None:
        rows = read(folder / 'candidates.json')
        processor.image_processor.size = TRAIN_PIXELS
        return processor, {'size': TRAIN_PIXELS}, {'generation': read(folder / 'model-settings.json')}, rows, \
            candidate_prompts(processor, folder, rows)
    protocol = read(source / 'protocol.json')
    size = {'shortest_edge': protocol['image']['min_pixels'], 'longest_edge': protocol['image']['max_pixels']}
    processor.image_processor.size = size
    rows, prompts = mmmu_prompts(source, out, processor, AutoConfig.from_pretrained(path, local_files_only=True))
    return processor, {'size': size, 'do_resize': False}, protocol, rows, prompts


def score(row, text, finish):
    from mmdl.evaluation.final_answer_parser_v8 import score_response
    return score_response(text, row.get('question_type', 'open'), row.get('options', []), row['answer'], finish,
                          question=row['question'])


def evaluate(source, out, arms, split, folder=None):
    from mmdl.runtime.artifacts import digest as canonical_digest
    from mmdl.runtime.contracts import sample_seed
    from experiment import CUE, decode, has_explicit_answer
    from run import request_settings
    from run_full import emit, packet, read
    import run_pilot as pilot

    started = time.monotonic()
    path = out / 'merged' / 'sft' if arms == ('sft2048',) else snapshot(out)
    processor, size, protocol, rows, prompts = eval_inputs(source, out, folder, path)
    expected_n = len(FAMILIES) * DEVELOPMENT if folder else 900
    if len(rows) != expected_n:
        raise ValueError('Unexpected evaluation coverage')
    cue_ids = processor.tokenizer.encode(CUE, add_special_tokens=False)
    if decode(processor.tokenizer, cue_ids) != CUE or len(cue_ids) != 4:
        raise ValueError('Unexpected final answer cue')
    kwargs = {'logits_processors': ['experiment:FinishCue']} if 'cue2048' in arms else {}
    if not folder:
        if [row['id'] for row in rows] != read(source / 'audit.json')['evaluation_ids']:
            raise ValueError('MMMU evaluation IDs or order differ')
        if max(row['input_tokens'] for row in rows) + CAP > CONTEXT:
            raise ValueError('Evaluation context exceeds limit')
    llm = pilot.engine(path, size, BATCH, CONTEXT, max(len(p['multi_modal_data']['image'])
                       if isinstance(p['multi_modal_data']['image'], list) else 1 for p in prompts), **kwargs)

    def params(row, arm):
        result = request_settings(protocol, row['seed'] if 'seed' in row else sample_seed(pilot.SEED, row['id']), CAP)
        if arm == 'cue2048':
            result.extra_args = {'finish_cue': {'ids': cue_ids, 'boundary': BOUNDARY,
                                               'question': row['question'], 'options': row.get('options', []),
                                               'question_type': row.get('question_type', 'open')}}
        return result

    requests = {arm: set() for arm in arms}
    totals = {arm: Counter() for arm in arms}
    durations, indices, raw_index = Counter(), {}, {}
    short_name = 'sft' if arms == ('sft2048',) else 'orig'
    storage = out / 'recovery'
    storage.mkdir(exist_ok=True)
    for start in range(0, expected_n, WINDOW):
        stop = min(start + WINDOW, expected_n)
        group = rows[start:stop]
        records = [{k: row[k] for k in ('id', 'subject', 'input_sha256', 'actual_engine_prompt_token_ids_sha256')
                    if k in row} for row in group]
        order = arms if (start // WINDOW) % 2 == 0 else arms[::-1]
        for arm in order:
            tick = time.monotonic()
            outputs = llm.generate(prompts[start:stop], [params(row, arm) for row in group], use_tqdm=False)
            durations[arm] += time.monotonic() - tick
            for row, record, output in zip(group, records, outputs, strict=True):
                result, = output.outputs
                token_ids = list(result.token_ids)
                if (not output.finished or not 0 < len(token_ids) <= CAP
                        or result.finish_reason not in ('stop', 'length') or output.request_id in requests[arm]):
                    raise ValueError(f"Invalid or duplicate generation: {arm} {row['id']}")
                requests[arm].add(output.request_id)
                prompt_sha = canonical_digest(list(output.prompt_token_ids))
                if not folder and prompt_sha != row['actual_engine_prompt_token_ids_sha256']:
                    raise ValueError(f"Engine prompt token hash changed: {arm} {row['id']}")
                if record.setdefault('actual_engine_prompt_token_ids_sha256', prompt_sha) != prompt_sha:
                    raise ValueError(f"Conditions used different prompts: {row['id']}")
                route = 'free'
                if arm == 'cue2048':
                    route = 'stopped_before_cue'
                    if len(token_ids) > BOUNDARY:
                        explicit = has_explicit_answer(decode(processor.tokenizer, token_ids[:BOUNDARY]),
                                                       row.get('question_type', 'open'), row.get('options', []),
                                                       row['question'])
                        route = 'already_declared' if explicit else 'forced_cue'
                        if not explicit and token_ids[BOUNDARY:BOUNDARY+len(cue_ids)] != cue_ids:
                            raise ValueError(f"Actual generated tokens missed the cue: {row['id']}")
                raw = result.text
                answer = score(row, raw, result.finish_reason)
                totals[arm].update({'correct': answer['correct'], 'hit_cap': len(token_ids) == CAP,
                                    'no_parse': answer['parse_status'] != 'PARSED', 'forced_cue': route == 'forced_cue'})
                record[arm] = answer | {'raw_response': raw, 'finish_reason': result.finish_reason,
                                        'generated_tokens': len(token_ids), 'route': route}
        number = start // WINDOW + 1
        raw_name = f'raw-{split}-{short_name}-{number:03d}'
        raw = gzip.compress(json_bytes(records), compresslevel=6, mtime=0)
        (storage / f'{raw_name}.json.gz').write_bytes(raw)
        raw_index[raw_name] = digest(raw)
        output_name = f'rows-{split}-{short_name}-{number:03d}'
        compact = [[r['id'], *[[r[a][key] for key in ROW_FIELDS] for a in arms]] for r in records]
        indices[output_name] = packet(out, output_name, compact)
        emit('EVAL_PROGRESS', {'split': split, 'arms': arms, 'n': stop, 'target': expected_n,
                               'counts': totals, 'generation_seconds': durations})
    if any(len(ids) != expected_n for ids in requests.values()):
        raise ValueError('Missing evaluation requests')
    report = {'arms': arms, 'row_fields': ROW_FIELDS, 'indices': indices, 'raw_indices': raw_index,
              'counts': totals, 'n': expected_n, 'generation_seconds': durations, 'seconds': time.monotonic() - started}
    write(out / f'{split}-{short_name}.json', report)
    emit('EVAL_COMPLETE', {'split': split, 'arms': arms, 'n': expected_n, 'counts': totals,
                           'generation_seconds': durations})


def compare(source, out):
    from run_full import SCORE_FIELDS, emit, packet, read
    import run_pilot as pilot

    storage = out / 'recovery'
    audit = read(source / 'audit.json')

    def verified_pairs(split, inputs):
        by_id = {}
        duration, compact = {}, {}
        regrades = 0
        for stage in ('orig', 'sft'):
            index = read(out / f'{split}-{stage}.json')
            duration.update(index['generation_seconds'])
            compact.update(index['indices'])
            rows = []
            for name, expected in index['raw_indices'].items():
                blob = (storage / f'{name}.json.gz').read_bytes()
                if digest(blob) != expected:
                    raise ValueError(f'Changed raw result archive: {name}')
                rows.extend(json.loads(gzip.decompress(blob)))
            if [r['id'] for r in rows] != [r['id'] for r in inputs]:
                raise ValueError(f'Missing or duplicate rows: {split} {stage}')
            for item, result in zip(inputs, rows, strict=True):
                sid = item['id']
                parts = by_id.setdefault(sid, {})
                for key in ('input_sha256', 'actual_engine_prompt_token_ids_sha256'):
                    if parts.setdefault(key, result.get(key)) != result.get(key):
                        raise ValueError(f'Paired inference inputs differ: {sid} {key}')
                    if key in item and item[key] != result.get(key):
                        raise ValueError(f'Archived inference input differs: {sid} {key}')
                for arm in index['arms']:
                    row = result[arm]
                    checked = score(item, row['raw_response'], row['finish_reason'])
                    if arm in parts or any(row[key] != checked[key] for key in SCORE_FIELDS):
                        raise ValueError(f'Paired V8 regrade differs: {split} {arm} {sid}')
                    parts[arm] = row
                    regrades += 1
        return by_id, duration, compact, regrades

    def summarize(pairs, rows, times):
        results = {arm: [{'id': r['id'], 'input_sha256': pairs[r['id']]['input_sha256'],
                          'actual_engine_prompt_token_ids_sha256': pairs[r['id']]['actual_engine_prompt_token_ids_sha256'],
                          **pairs[r['id']][arm]} for r in rows] for arm in ARMS}
        report = pilot.compare(rows, results, times)
        for value in report['comparisons'].values():
            value['group_sizes'] = {k: len(v) for k, v in value.pop('groups').items()}
        return report

    rows = read(source / 'mmmu.json')
    development = read(source / 'development/candidates.json')
    pairs, times, indices, grades = verified_pairs('mmmu', rows)
    dev_pairs, dev_times, dev_indices, dev_grades = verified_pairs('dev', development)
    engineering = [r for r in rows if r['subject'] in audit['engineering_subjects']]
    changed = {direction: [r for r in rows if pairs[r['id']]['base2048']['correct'] is (direction == 'lost')
                           and pairs[r['id']]['sft2048']['correct'] is (direction == 'gained')]
               for direction in ('gained', 'lost')}
    examples = {}
    for direction, group in changed.items():
        group.sort(key=lambda r: (pairs[r['id']]['base2048']['finish_reason'] != 'length',
                                  r['subject'] not in audit['engineering_subjects'], r['id']))
        examples[direction] = [{k: r[k] for k in ('id', 'subject', 'question', 'answer', 'options')} |
                               {arm: {k: pairs[r['id']][arm][k] for k in ROW_FIELDS}
                                | {'raw_tail': pairs[r['id']][arm]['raw_response'][-900:]} for arm in ARMS}
                               for r in group[:6]]
    report = {'overall': summarize(pairs, rows, times), 'engineering': summarize(pairs, engineering, times),
              'development': summarize(dev_pairs, development, dev_times),
              'by_subject': {subject: summarize(pairs, [r for r in rows if r['subject'] == subject], times)
                             for subject in sorted({r['subject'] for r in rows})},
              'engineering_subjects': audit['engineering_subjects'],
              'verified_ids': [r['id'] for r in rows], 'input_checks': grades, 'development_input_checks': dev_grades,
              'examples': examples, 'indices': indices, 'development_indices': dev_indices,
              'generation_seconds': times, 'development_seconds': dev_times,
              'cap': CAP, 'boundary': BOUNDARY, 'batch': BATCH, 'window': WINDOW, 'model_revision': pilot.REVISION,
              'engine_seed': pilot.SEED, 'training_manifest_sha256': read(out / 'training.json')['train_sha256'],
              'merge': read(out / 'sft-merge.json'), 'parser': pilot.PARSER,
              'forced': sum(p['cue2048']['route'] == 'forced_cue' for p in pairs.values())}
    write(out / 'verified.json', report)
    packet(out, 'verified', report)
    emit('LEARNED_FINISH_COMPLETE', {'metrics': report['overall']['metrics'],
                                    'paired': report['overall']['comparisons'], 'input_checks': grades})


def main():
    if sys.argv[1:] == ['build']:
        build()
        return
    stage, *paths = sys.argv[1:]
    source, repo, out = map(Path, paths)
    if 'VLLM_BATCH_INVARIANT' in os.environ:
        raise ValueError('Batch-invariant flag is unsupported by the pinned vLLM')
    os.environ['VLLM_ENABLE_V1_MULTIPROCESSING'] = '0'
    if stage == 'preflight':
        preflight(source, repo, out)
    elif stage == 'collect':
        collect(source / 'training', out)
    elif stage == 'train':
        train(source / 'training', out)
    elif stage == 'merge':
        from run_full import emit, packet, read
        import run_pilot as pilot
        pilot.merge_stage(source, out, arms=('sft',))
        merge = read(out / 'sft-merge.json')
        packet(out, 'merge', merge)
        emit('MERGED', merge)
    elif stage == 'development':
        # Separate processes free the base engine before the merged adapter loads.
        import subprocess
        for arm in ('dev-base', 'dev-sft'):
            subprocess.run([sys.executable, __file__, arm, str(source), str(repo), str(out)], check=True)
    elif stage in ('dev-base', 'dev-sft', 'eval-base', 'eval-sft'):
        arms = ('sft2048',) if stage.endswith('sft') else ('base2048', 'cue2048')
        dev = stage.startswith('dev')
        evaluate(source, out, arms, 'dev' if dev else 'mmmu', source / 'development' if dev else None)
    elif stage == 'compare':
        compare(source, out)
    else:
        raise ValueError(f'Unknown experiment stage: {stage}')


if __name__ == '__main__':
    main()
