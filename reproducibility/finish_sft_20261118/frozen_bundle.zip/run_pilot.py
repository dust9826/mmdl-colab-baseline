"""Train matched Q/V LoRAs with verified chosen responses and actual Qwen errors."""

import argparse
from collections import Counter
import gc
from hashlib import file_digest, sha256
from importlib.metadata import version
from itertools import combinations
import json
from math import comb
from pathlib import Path
import random
import re
import shutil
from statistics import mean, median
import time

from PIL import Image


SEED = 3407
MODEL = 'Qwen/Qwen3-VL-4B-Instruct'
REVISION = 'ebb281ec70b05090aa6165b016eac8ec08e71b17'
TRAIN_PIXELS = {'shortest_edge': 65536, 'longest_edge': 262144}
PAIR_CAP = 256
PAIR_LIMIT = 24
EPOCHS = 2
RANK = 8
LR = 5e-5
BETA = 0.1
CAP = 2048
EVAL_BATCH = 8
ARMS = ('base', 'sft', 'dpo')
PARSER = 'team-final-answer-v8'
FINAL = re.compile(r'^\s*(?:final\s+)?answer\s*:\s*\(?([A-Z])\)?\.?\s*$', re.IGNORECASE)
GROUP = {(True, True): 'both_correct', (False, True): 'wrong_to_correct',
         (True, False): 'correct_to_wrong', (False, False): 'both_wrong'}


def load(path):
    return json.loads(path.read_text())


def dump(path, value):
    pending = path.with_suffix(path.suffix + '.pending')
    pending.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n')
    pending.replace(path)


def append(path, value):
    with path.open('a') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n')


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def emit(event, value):
    print('PREF_' + event + ' ' + json.dumps(value, ensure_ascii=False, allow_nan=False), flush=True)


def file_sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def load_rgb(path, expected):
    with Image.open(path) as original:
        image = original.convert('RGB')
    digest = sha256(f'{image.width}x{image.height}:'.encode() + image.tobytes()).hexdigest()
    if digest != expected:
        raise ValueError(f'Input RGB mismatch {path.name}')
    return image


def train_input(processor, source, row):
    image = load_rgb(source / 'train-images' / f"{row['id']}.webp", row['image_rgb_sha256'])
    messages = [{'role': 'user', 'content': [{'type': 'image', 'image': image},
                                           {'type': 'text', 'text': row['prompt']}]}]
    return processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True), image


def visible_answer(text):
    lines = text.strip().splitlines()
    if len(lines) < 2:
        return None
    match = FINAL.fullmatch(lines[-1].replace('**', ''))
    if not match:
        return None
    answer = match.group(1).upper()
    rationale = '\n'.join(lines[:-1]).strip()
    # Do not treat multiple answer declarations, or answer-only guesses, as clean errors.
    if len(rationale.split()) < 8 or re.search(r'(?im)^\s*(?:\*\*)?(?:final\s+)?answer\s*:', rationale):
        return None
    return answer, f'{rationale}\nFinal answer: ({answer})'


def engine(model, size, batch, max_model_len, images, **kwargs):
    from vllm import LLM

    return LLM(model=str(model), tokenizer=str(model), dtype='bfloat16', seed=SEED,
               tensor_parallel_size=1, max_num_seqs=batch, max_model_len=max_model_len,
               gpu_memory_utilization=0.90, enforce_eager=True, trust_remote_code=False,
               enable_prefix_caching=False, async_scheduling=False, mm_processor_cache_gb=0,
               limit_mm_per_prompt={'image': images, 'video': 0}, mm_processor_kwargs=size, **kwargs)


def count_tokens(processor, text):
    return len(processor.tokenizer.encode(text, add_special_tokens=False))


def pair_stage(source, out):
    from huggingface_hub import snapshot_download
    from transformers import AutoProcessor
    from vllm import SamplingParams
    from mmdl.evaluation.final_answer_parser_v8 import score_response
    from mmdl.runtime.contracts import sample_seed

    started = time.monotonic()
    emit('MODEL_DOWNLOAD', {'model': MODEL, 'revision': REVISION})
    model = Path(snapshot_download(MODEL, revision=REVISION, allow_patterns=[
        '*.safetensors', '*.json', '*.txt', '*.jinja', '*.model',
    ]))
    if model.name != REVISION:
        raise ValueError('Unexpected model revision')
    dump(out / 'model.json', {'snapshot': str(model), 'id': MODEL, 'revision': REVISION})
    processor = AutoProcessor.from_pretrained(model, local_files_only=True, use_fast=True)
    processor.image_processor.size = TRAIN_PIXELS
    llm = engine(model, {'size': TRAIN_PIXELS}, 16, 4096, 1)
    training = load(source / 'train.json')
    selected = {name: [] for name in sorted({r['source'] for r in training})}
    frequencies = Counter()
    for start in range(0, len(training), 12):
        group = training[start:start + 12]
        prompts = []
        for row in group:
            prompt, image = train_input(processor, source, row)
            prompts.append({'prompt': prompt, 'multi_modal_data': {'image': image}})
        sampling = [SamplingParams(n=3, max_tokens=PAIR_CAP, temperature=0.9, top_p=0.95,
                                   top_k=40, seed=sample_seed(SEED, row['id'])) for row in group]
        outputs = llm.generate(prompts, sampling, use_tqdm=False)
        for row, output in zip(group, outputs, strict=True):
            # The vLLM multimodal path may omit the echoed text. The training
            # stage checks the actual expanded prompt token IDs against HF.
            if not output.finished or not output.prompt_token_ids or len(output.outputs) != 3:
                raise ValueError(f"Candidate coverage changed {row['id']}: {len(output.outputs)} outputs")
            accepted = []
            chosen_len = count_tokens(processor, row['chosen'])
            for candidate in output.outputs:
                raw = candidate.text
                status = score_response(raw, 'multiple-choice', row['options'], row['answer'],
                                        candidate.finish_reason, question=row['question'])
                explicit = visible_answer(raw)
                label, negative = explicit or (None, None)
                if candidate.finish_reason != 'stop':
                    category = 'not_stopped'
                elif not explicit or label not in [chr(65 + i) for i in range(len(row['options']))]:
                    category = 'no_unambiguous_final'
                elif status['parsed_answer'] != label:
                    category = 'parser_disagreement'
                elif label == row['answer']:
                    category = 'correct'
                else:
                    length = count_tokens(processor, negative)
                    ratio = length / chosen_len
                    category = 'eligible' if 0.5 <= ratio <= 2 else 'length_mismatch'
                    if category == 'eligible':
                        accepted.append((abs(length - chosen_len), candidate.index, {
                            'rejected': negative, 'rejected_raw': raw, 'rejected_answer': label,
                            'rejected_token_ids_original': list(candidate.token_ids),
                            'rejected_finish_reason': candidate.finish_reason, 'rejected_tokens': length,
                            'chosen_tokens': chosen_len, 'rejected_candidate_index': candidate.index,
                            'prompt_token_sha256': sha256(json.dumps(output.prompt_token_ids).encode()).hexdigest(),
                        }))
                frequencies[f"{row['source']}:{category}"] += 1
                append(out / 'candidates.jsonl', {'id': row['id'], 'source': row['source'],
                       'candidate': candidate.index, 'raw_response': raw, 'parsed_answer': status['parsed_answer'],
                       'finish_reason': candidate.finish_reason, 'token_ids': list(candidate.token_ids),
                       'selection_status': category})
            if accepted:
                best = min(accepted, key=lambda item: item[:2])[2]
                selected[row['source']].append(row | best)
        emit('PAIR_PROGRESS', {'processed': start + len(group), 'candidate_total': len(training),
                               'eligible_questions': {name: len(choices) for name, choices in selected.items()}})

    for choices in selected.values():
        choices.sort(key=lambda row: (abs(row['chosen_tokens'] - row['rejected_tokens']),
                                     sha256(f"{SEED}:{row['id']}".encode()).hexdigest()))
    balanced = []
    for _ in range(PAIR_LIMIT):
        for choices in selected.values():
            if choices and len(balanced) < PAIR_LIMIT:
                balanced.append(choices.pop(0))
    if not balanced:
        raise ValueError('No verified wrong answers met the predeclared pair rules')
    dump(out / 'pairs.json', balanced)
    summary = {'pairs': len(balanced), 'by_source': dict(Counter(r['source'] for r in balanced)),
               'rollouts': sum(frequencies.values()), 'filter_counts': dict(frequencies),
               'mean_chosen_tokens': mean(r['chosen_tokens'] for r in balanced),
               'mean_rejected_tokens': mean(r['rejected_tokens'] for r in balanced),
               'pair_sha256': file_sha(out / 'pairs.json'), 'seconds': time.monotonic() - started}
    dump(out / 'pairs-summary.json', summary)
    emit('PAIRS_READY', summary)


def completion_logp(model, base, batch, tokens):
    """Select logits predicting assistant tokens, following the earlier GRPO pilot."""
    import torch

    prefix = batch['input_ids']
    target = torch.tensor([tokens], device=prefix.device)
    full = dict(batch)
    full['input_ids'] = torch.cat((prefix, target), dim=-1)
    full['attention_mask'] = torch.cat((batch['attention_mask'], torch.ones_like(target)), dim=-1)
    for key in ('token_type_ids', 'mm_token_type_ids'):
        if key in full:
            full[key] = torch.cat((full[key], torch.zeros_like(target)), dim=-1)
    base.model.rope_deltas = None
    logits = model(**full, logits_to_keep=len(tokens) + 1, use_cache=False).logits[:, :-1].float()
    logp = logits.log_softmax(dim=-1).gather(-1, target.unsqueeze(-1)).flatten()
    if logp.numel() != len(tokens) or not bool(logp.isfinite().all()):
        raise ValueError('Completion log probabilities are misaligned or nonfinite')
    return logp


def train_stage(source, out, arms=('sft', 'dpo')):
    import torch
    from peft import LoraConfig, get_peft_model, get_peft_model_state_dict, set_peft_model_state_dict
    from peft.utils.save_and_load import load_peft_weights
    from torch.nn.functional import logsigmoid
    from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

    started = time.monotonic()
    path = load(out / 'model.json')['snapshot']
    torch.manual_seed(SEED)
    processor = AutoProcessor.from_pretrained(path, local_files_only=True, use_fast=True)
    processor.image_processor.size = TRAIN_PIXELS
    base = Qwen3VLForConditionalGeneration.from_pretrained(path, local_files_only=True,
              dtype=torch.bfloat16, attn_implementation='sdpa', device_map={'': 'cuda:0'})
    names = [name for name, module in base.named_modules() if isinstance(module, torch.nn.Linear)
             and '.language_model.layers.' in name and name.rsplit('.', 1)[-1] in ('q_proj', 'v_proj')]
    if len(names) != 2 * base.config.text_config.num_hidden_layers or base.config.text_config.attention_dropout != 0:
        raise ValueError('Unexpected LoRA target modules or stochastic attention dropout')
    model = get_peft_model(base, LoraConfig(r=RANK, lora_alpha=2 * RANK, lora_dropout=0.0,
                                          bias='none', target_modules=names, task_type='CAUSAL_LM'))
    parameters = {name: value for name, value in model.named_parameters() if value.requires_grad}
    if not parameters or any('lora_' not in name or '.language_model.layers.' not in name for name in parameters):
        raise ValueError('Unexpected trainable parameter')
    initial = {name: tensor.detach().cpu().clone() for name, tensor in get_peft_model_state_dict(model).items()}
    if not any('lora_B' in name for name in initial) or any(t.count_nonzero() for n, t in initial.items() if 'lora_B' in n):
        raise ValueError('Expected zero initial LoRA residual')
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
    model.enable_input_require_grads()
    selected = load(out / 'pairs.json')
    cached = {}
    reference = {}
    for row in selected:
        prompt, image = train_input(processor, source, row)
        batch = processor(text=[prompt], images=[image], return_tensors='pt')
        token_hash = sha256(json.dumps(batch['input_ids'][0].tolist()).encode()).hexdigest()
        if token_hash != row['prompt_token_sha256']:
            raise ValueError(f"Training and negative candidate prompt tokens differ {row['id']}")
        eos = processor.tokenizer.eos_token_id
        chosen = processor.tokenizer.encode(row['chosen'], add_special_tokens=False) + [eos]
        rejected = processor.tokenizer.encode(row['rejected'], add_special_tokens=False) + [eos]
        cached[row['id']] = batch, chosen, rejected

    def logps(sid):
        batch, chosen, rejected = cached[sid]
        gpu = {k: tensor.to('cuda:0') for k, tensor in batch.items()}
        return completion_logp(model, base, gpu, chosen), completion_logp(model, base, gpu, rejected)

    model.eval()
    with torch.no_grad(), model.disable_adapter():
        for row in selected:
            reference[row['id']] = [value.detach().cpu() for value in logps(row['id'])]
    probe = selected[0]['id']
    with torch.no_grad():
        current = logps(probe)
        initial_delta = max(float((a.cpu() - b).abs().max()) for a, b in zip(current, reference[probe], strict=True))
    if initial_delta > 1e-5:
        raise ValueError(f'Initial policy/reference mismatch {initial_delta}')
    order = []
    for epoch in range(EPOCHS):
        ids = list(cached)
        random.Random(SEED + epoch).shuffle(ids)
        order.extend(ids)
    state = {'initial_ref_max_abs_per_token_diff': initial_delta, 'reference_probe': probe, 'order': order,
             'target_modules': names, 'trainable_parameters': sum(p.numel() for p in parameters.values()),
             'rank': RANK, 'learning_rate': LR, 'beta': BETA, 'seed': SEED, 'epochs': EPOCHS,
             'pair_sha256': file_sha(out / 'pairs.json'), 'training_preprocessing': TRAIN_PIXELS,
             'versions': {p: version(p) for p in ('torch', 'transformers', 'peft', 'Pillow')}, 'arms': {}}
    emit('TRAIN_READY', {'pairs': len(selected), 'updates_per_arm': len(order), 'trainable_parameters': state['trainable_parameters']})
    dump(out / 'training.json', state)
    for arm in arms:
        began = time.monotonic()
        set_peft_model_state_dict(model, initial)
        torch.manual_seed(SEED)
        torch.cuda.reset_peak_memory_stats()
        optimizer = torch.optim.AdamW(parameters.values(), lr=LR, weight_decay=0.0)
        model.train()
        for step, sid in enumerate(order, 1):
            optimizer.zero_grad(set_to_none=True)
            if arm == 'sft':
                batch, tokens, _ = cached[sid]
                gpu = {k: tensor.to('cuda:0') for k, tensor in batch.items()}
                loss = -completion_logp(model, base, gpu, tokens).mean()
                margin = None
            else:
                chosen, rejected = logps(sid)
                ref_c, ref_r = (item.sum().to('cuda:0') for item in reference[sid])
                margin = (chosen.sum() - ref_c) - (rejected.sum() - ref_r)
                loss = -logsigmoid(BETA * margin)
            if not bool(loss.isfinite()):
                raise ValueError(f'{arm}: nonfinite loss')
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(parameters.values(), 1.0, error_if_nonfinite=True)
            optimizer.step()
            step_log = {'arm': arm, 'id': sid, 'step': step, 'loss': float(loss.detach()),
                        'gradient_norm': float(norm), 'preupdate_dpo_margin': None if margin is None else float(margin.detach())}
            append(out / 'updates.jsonl', step_log)
            if step == 1 or step % 8 == 0 or step == len(order):
                emit('UPDATE', step_log)
        del optimizer
        final = {name: tensor.detach().cpu() for name, tensor in get_peft_model_state_dict(model).items()}
        changed = sum(not torch.equal(final[name], value) for name, value in initial.items())
        if not changed or any(not bool(t.isfinite().all()) for t in final.values()):
            raise ValueError(f'{arm}: no finite weight update')
        directory = out / arm / 'adapter'
        model.save_pretrained(directory, safe_serialization=True)
        reloaded = load_peft_weights(directory, device='cpu')
        if set(reloaded) != set(final) or any(not torch.equal(reloaded[n], t) for n, t in final.items()):
            raise ValueError(f'{arm}: saved adapter differs from trained adapter')
        set_peft_model_state_dict(model, reloaded)
        model.eval()
        with torch.no_grad(), model.disable_adapter():
            frozen = logps(probe)
            ref_delta = max(float((a.cpu() - b).abs().max()) for a, b in zip(frozen, reference[probe], strict=True))
        if ref_delta > 1e-5:
            raise ValueError(f'{arm}: frozen reference changed')
        with torch.no_grad():
            trained_probe = logps(probe)
            shift = max(float((a.cpu() - b).abs().max()) for a, b in zip(trained_probe, reference[probe], strict=True))
        state['arms'][arm] = {'updates': len(order), 'changed_tensors': changed, 'reloaded': True,
                              'reference_max_abs_per_token_diff': ref_delta,
                              'policy_probe_max_abs_per_token_shift': shift,
                              'seconds': time.monotonic() - began,
                              'peak_cuda_gib': torch.cuda.max_memory_allocated() / 2**30,
                              'adapter_sha256': file_sha(directory / 'adapter_model.safetensors')}
        dump(out / 'training.json', state)
        emit('TRAINED', {'arm': arm} | state['arms'][arm])
    state['total_seconds'] = time.monotonic() - started
    dump(out / 'training.json', state)


def compare(inputs, results, generation_times):
    metrics = {}
    n = len(inputs)
    for arm, records in results.items():
        if len(records) != n or [row['id'] for row in records] != [row['id'] for row in inputs]:
            raise ValueError(f'{arm}: Missing, duplicate, or misordered evaluation rows')
        metrics[arm] = {'correct': sum(row['correct'] for row in records), 'n': n,
                        'mean_tokens': mean(row['generated_tokens'] for row in records),
                        'median_tokens': median(row['generated_tokens'] for row in records),
                        'token_cap': sum(row['generated_tokens'] == CAP for row in records),
                        'parse_failures': sum(row['parse_status'] != 'PARSED' for row in records),
                        'generation_seconds': generation_times[arm]}
    comparisons = {}
    for left, right in combinations(results, 2):
        groups = {value: [] for value in GROUP.values()}
        for a, b in zip(results[left], results[right], strict=True):
            if (a['id'], a['input_sha256'], a['actual_engine_prompt_token_ids_sha256']) != (
                    b['id'], b['input_sha256'], b['actual_engine_prompt_token_ids_sha256']):
                raise ValueError('Unmatched paired evaluation inputs')
            groups[GROUP[a['correct'], b['correct']]].append(a['id'])
        up, down = (len(groups[name]) for name in ('wrong_to_correct', 'correct_to_wrong'))
        total = up + down
        p = min(1.0, 2 * sum(comb(total, k) for k in range(min(up, down) + 1)) / 2**total)
        comparisons[f'{left}_to_{right}'] = {'groups': groups, 'delta_correct': up - down,
                                             'delta_percentage_points': (up - down) / n * 100,
                                             'mcnemar_exact_p': p}
    return {'metrics': metrics, 'comparisons': comparisons}


def merge_stage(source, out, arms=('sft', 'dpo')):
    """Fold each existing LoRA into a fresh BF16 copy for vLLM inference."""
    import torch
    from peft import PeftModel
    from transformers import AutoConfig, Qwen3VLForConditionalGeneration

    state = load(out / 'training.json')
    path = Path(load(out / 'model.json')['snapshot'])
    reference = AutoConfig.from_pretrained(path, local_files_only=True).to_dict()
    for arm in arms:
        start = time.monotonic()
        adapter = out / arm / 'adapter'
        adapter_hash = file_sha(adapter / 'adapter_model.safetensors')
        if adapter_hash != state['arms'][arm]['adapter_sha256']:
            raise ValueError(f'{arm}: trained adapter hash changed before merge')
        base = Qwen3VLForConditionalGeneration.from_pretrained(path, local_files_only=True,
                  dtype=torch.bfloat16, attn_implementation='sdpa', device_map={'': 'cuda:0'})
        check_names = [state['target_modules'][i] for i in (0, len(state['target_modules']) // 2, -1)]
        before = {name: base.get_submodule(name).weight.detach().clone() for name in check_names}
        policy = PeftModel.from_pretrained(base, adapter, is_trainable=False)
        merged = policy.merge_and_unload(safe_merge=True)
        changes = {name: int(torch.count_nonzero(merged.get_submodule(name).weight != weight))
                   for name, weight in before.items()}
        if not all(changes.values()):
            raise ValueError(f'{arm}: sampled Q/V weights did not change after BF16 merge')
        directory = out / 'merged' / arm
        merged.save_pretrained(directory, safe_serialization=True)
        for file in path.iterdir():
            if file.is_file() and file.suffix in ('.txt', '.json', '.jinja', '.model') and file.name not in (
                    'config.json', 'model.safetensors.index.json'):
                shutil.copyfile(file, directory / file.name)
        model_cfg = AutoConfig.from_pretrained(directory, local_files_only=True).to_dict()
        if any(model_cfg[key] != reference[key] for key in ('model_type', 'text_config', 'vision_config')):
            # The save may serialize dtype metadata where the upstream config omits it.
            for key in ('text_config', 'vision_config'):
                for field in ('dtype', 'torch_dtype', '_name_or_path', 'transformers_version'):
                    model_cfg[key].pop(field, None)
                    reference[key].pop(field, None)
            if any(model_cfg[key] != reference[key] for key in ('model_type', 'text_config', 'vision_config')):
                raise ValueError(f'{arm}: checkpoint architecture changed during merge')
        report = {'arm': arm, 'adapter_sha256': adapter_hash, 'sampled_changed_elements': changes,
                  'merge_dtype': 'bfloat16', 'seconds': time.monotonic() - start}
        dump(out / f'{arm}-merge.json', report)
        emit('MERGED', report)
        del before, policy, merged, base
        gc.collect()
        torch.cuda.empty_cache()


def evaluation_stage(source, out, arm, *, per_subject=1):
    from transformers import AutoConfig, AutoProcessor
    from vllm import SamplingParams
    from mmdl.evaluation.backends.input_preparation import prepare_protocol_inputs
    from mmdl.evaluation.parsers import score_with_parser
    from mmdl.runtime.artifacts import digest
    from mmdl.runtime.contracts import sample_seed

    began = time.monotonic()
    protocol = load(source / 'protocol.json')
    generation = protocol['generation']
    if generation['max_new_tokens'] != CAP or generation['seed'] != SEED or protocol['parser'] != PARSER:
        raise ValueError('Archived evaluation protocol changed')
    path = load(out / 'model.json')['snapshot']
    processor = AutoProcessor.from_pretrained(path, local_files_only=True, use_fast=True)
    config = AutoConfig.from_pretrained(path, local_files_only=True)
    image_cfg = protocol['image']
    size = {'shortest_edge': image_cfg['min_pixels'], 'longest_edge': image_cfg['max_pixels']}
    processor.image_processor.size = size
    examples = load(source / 'mmmu.json')
    rgb = load(source / 'mmmu-rgb.json')
    subjects = Counter(r['subject'] for r in examples)
    if len(subjects) != 30 or set(subjects.values()) != {per_subject} or len({r['id'] for r in examples}) != len(examples):
        raise ValueError('Evaluation coverage changed')
    prompts = []
    samples = []
    max_images = 1
    for row in examples:
        messages, images = [], []
        for message in row['messages']:
            blocks = []
            for block in message['content']:
                if block['type'] == 'image':
                    hash_ = block['sha256']
                    image = load_rgb(source / 'mmmu-images' / f'{hash_}.webp', rgb[hash_])
                    images.append(image)
                    blocks.append({'type': 'image', 'image': image})
                else:
                    blocks.append(block)
            messages.append({'role': message['role'], 'content': blocks})
        item, processed = prepare_protocol_inputs(processor, config, messages, images, image_cfg)
        if item['input_sha256'] != row['input_sha256'] or item['chat_prompt'] != row['chat_prompt']:
            raise ValueError(f"{row['id']}: archived P0 input tensor hash or prompt mismatch")
        if sample_seed(SEED, row['id']) != row['seed'] or item['input_tokens'] + CAP > 8192:
            raise ValueError(f"{row['id']}: request seed or context mismatch")
        max_images = max(max_images, len(images))
        prompts.append({'prompt': item['chat_prompt'], 'multi_modal_data': {'image': processed}})
        samples.append(SamplingParams(n=1, temperature=generation['temperature'], top_p=generation['top_p'],
                        top_k=generation['top_k'], repetition_penalty=generation['repetition_penalty'],
                        presence_penalty=generation['presence_penalty'], max_tokens=CAP, seed=row['seed']))
    emit('INPUT_MATCH', {'arm': arm, 'n': len(examples), 'subjects': 30,
                         'archived_p0_tensor_hashes': len(prompts)})
    checkpoint = path if arm == 'base' else out / 'merged' / arm
    llm = engine(checkpoint, {'size': size, 'do_resize': False}, EVAL_BATCH, 8192, max_images)
    identity = {'model': MODEL, 'revision': REVISION, 'generation': generation, 'image': image_cfg,
                'max_model_len': 8192, 'batch_size': EVAL_BATCH, 'engine_seed': SEED,
                'mp0': True, 'parser': PARSER, 'scorer_source': load(source / 'scorer_source.json'),
                'versions': {p: version(p) for p in ('torch', 'vllm', 'transformers', 'Pillow', 'qwen-vl-utils')}}
    records = []
    duration = 0.0
    response = out / f'{arm}-mmmu.jsonl'
    if response.exists():
        raise FileExistsError(response)
    for start in range(0, len(examples), EVAL_BATCH):
        stop = start + EVAL_BATCH
        step = time.monotonic()
        outputs = llm.generate(prompts[start:stop], samples[start:stop], use_tqdm=False)
        elapsed = time.monotonic() - step
        duration += elapsed
        for row, output in zip(examples[start:stop], outputs, strict=True):
            if digest(list(output.prompt_token_ids)) != row['actual_engine_prompt_token_ids_sha256']:
                raise ValueError(f"{row['id']}: actual vLLM prompt tokens differ from the archive")
            result, = output.outputs
            if not output.finished or not 0 < len(result.token_ids) <= CAP:
                raise ValueError(f"{row['id']}: incomplete generation")
            score = score_with_parser(result.text, row['question_type'], row['options'], row['answer'],
                                      PARSER, result.finish_reason, question=row['question'])
            record = {k: row[k] for k in ('id', 'subject', 'answer', 'question_type', 'input_sha256',
                                         'actual_engine_prompt_token_ids_sha256', 'seed')}
            record.update(score, raw_response=result.text, generated_tokens=len(result.token_ids),
                          generated_token_ids=list(result.token_ids), finish_reason=result.finish_reason,
                          stop_reason=result.stop_reason, batch_start=start, batch_seconds=elapsed,
                          checkpoint='base' if arm == 'base' else f'{arm} BF16-merged LoRA')
            records.append(record)
            append(response, record)
        emit('EVAL_PROGRESS', {'arm': arm, 'done': len(records), 'n': len(examples),
                               'correct_so_far': sum(r['correct'] for r in records),
                               'generation_seconds': elapsed})
    report = {'identity': identity, 'arm': arm, 'response_sha256': file_sha(response),
              'n': len(records), 'generation_seconds': duration,
              'wall_seconds': time.monotonic() - began}
    dump(out / f'{arm}-eval.json', report)


def compare_stage(source, out, arms=ARMS):
    examples = load(source / 'mmmu.json')
    identities = {arm: load(out / f'{arm}-eval.json') for arm in arms}
    if any(meta['identity'] != identities['base']['identity'] for meta in identities.values()):
        raise ValueError('The paired evaluation environment changed')
    results, durations = {}, {}
    for arm, meta in identities.items():
        response = out / f'{arm}-mmmu.jsonl'
        if file_sha(response) != meta['response_sha256'] or meta['n'] != len(examples):
            raise ValueError(f'{arm}: invalid response file')
        results[arm], durations[arm] = rows(response), meta['generation_seconds']
    summary = compare(examples, results, durations)
    summary.update(evaluation_seconds=sum(r['wall_seconds'] for r in identities.values()),
                   evaluation_ids=[r['id'] for r in examples],
                   response_sha256={arm: r['response_sha256'] for arm, r in identities.items()})
    dump(out / 'comparison.json', summary)
    emit('COMPLETE', summary['metrics'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('pairs', 'train', 'merge', *(f'eval-{arm}' for arm in ARMS), 'compare'))
    parser.add_argument('source', type=Path)
    parser.add_argument('out', type=Path)
    args = parser.parse_args()
    import torch

    torch.set_num_threads(4)
    if torch.cuda.device_count() != 1 or not torch.cuda.is_bf16_supported() or 'L4' not in torch.cuda.get_device_name(0):
        raise ValueError('Expected one BF16 NVIDIA L4')
    for entry in load(args.source / 'scorer_source.json')['files']:
        if file_sha(args.source / entry['path']) != entry['sha256']:
            raise ValueError('Frozen V8 source SHA-256 mismatch')
    if args.stage.startswith('eval-'):
        evaluation_stage(args.source, args.out, args.stage.removeprefix('eval-'))
    else:
        {'pairs': pair_stage, 'train': train_stage, 'merge': merge_stage,
         'compare': compare_stage}[args.stage](args.source, args.out)


if __name__ == '__main__':
    main()
