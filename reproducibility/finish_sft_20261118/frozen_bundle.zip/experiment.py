"""Compare one 2,048-token generation with a forced final cue and one plain 4,096 generation."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from statistics import mean, median
import sys
import time


HERE = Path(__file__).resolve().parent
JOB = 'single-call-finish-20261117'
NOTEBOOK = 'QWEN_SINGLE_CALL_2048_4096_L4_20261117.ipynb'
SHORT = 'single_finish_2048'
LONG = 'single_plain_4096'
PREFIX = 'stored_4096_prefix_2048'
BASELINE = 'archived_plain_2048'
ARMS = {SHORT: 2048, LONG: 4096}
BOUNDARY = 1920
CUE = '\n\nFinal answer:'
BATCH = 8
WINDOW = 24
CONTEXT = 12288


def decode(tokenizer, ids):
    return tokenizer.decode(ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)


def has_explicit_answer(text, question_type, options, question):
    from mmdl.evaluation.final_answer_parser_v8 import extract_mcq, extract_open

    grade = (extract_mcq(text, options, question=question) if question_type == 'multiple-choice'
             else extract_open(text, question=question))
    return grade['status'] == 'PARSED' and (grade['rule'].startswith('final_declaration:')
                                             or grade['rule'] == 'boxed_answer')


def forced_cue(tokenizer, cue_ids, boundary, question_type, options, question):
    """Make the boundary decision once using only the current output and public question."""
    insert = None

    def apply(output_ids, logits):
        nonlocal insert
        index = len(output_ids) - boundary
        if not 0 <= index < len(cue_ids):
            return logits
        if insert is None:
            insert = not has_explicit_answer(
                decode(tokenizer, output_ids[:boundary]), question_type, options, question)
        return force_token(logits, cue_ids[index]) if insert else logits

    return apply


def force_token(logits, token_id):
    logits.fill_(float('-inf'))
    logits[token_id] = 0.0
    return logits


# vLLM resolves this class by module name. The import below stays out of the CPU build.
if __name__ == 'experiment':
    from transformers import AutoTokenizer
    from vllm.v1.sample.logits_processor import AdapterLogitsProcessor

    class FinishCue(AdapterLogitsProcessor):
        def __init__(self, vllm_config, device, is_pin_memory):
            super().__init__(vllm_config, device, is_pin_memory)
            self.tokenizer = AutoTokenizer.from_pretrained(
                vllm_config.model_config.tokenizer, local_files_only=True)

        def is_argmax_invariant(self):
            return False

        def new_req_logits_processor(self, params):
            plan = (params.extra_args or {}).get('finish_cue')
            if plan is None:
                return None
            if not 0 < plan['boundary'] < params.max_tokens - len(plan['ids']):
                raise ValueError('The final cue must leave space for the answer')
            return forced_cue(self.tokenizer, plan['ids'], plan['boundary'],
                              plan['question_type'], plan['options'], plan['question'])


def build():
    import base64
    from io import BytesIO
    import textwrap
    from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
    from PIL import Image

    experiments = HERE.parent
    sys.path.insert(0, str(experiments / 'verified-preference-20261112'))
    from build_colab import ARCHIVE, BASELINE as BASE, SCORER, SOURCE_KEYS, rgb_digest
    sys.path.insert(0, str(experiments / 'scienceqa-scale-full-20261114'))
    from run_full import SCORE_FIELDS, read, write

    colab = experiments.parent
    prior = read(colab / 'results/reading-completion-20261117/gain-audit.json')
    engineering = list(prior['engineering_subjects'])
    old_manifest = read(BASE / 'run_manifest.json')
    ids = old_manifest['expected_ids']
    rows = []
    rgb = {}
    for sid in ids:
        row = read(BASE / 'samples' / (sid + '.json'))
        if row['id'] != sid or row['status'] != 'COMPLETED':
            raise ValueError(f'Archived record not complete: {sid}')
        for message in row['messages']:
            for block in message['content']:
                if block['type'] != 'image' or block['sha256'] in rgb:
                    continue
                path = BASE / block['image']
                if sha256(path.read_bytes()).hexdigest() != block['sha256']:
                    raise ValueError(f'Archived image checksum differs: {sid}')
                with Image.open(path) as raw:
                    rgb[block['sha256']] = rgb_digest(raw)
        before = {k: row[k] for k in (*SCORE_FIELDS, 'generated_tokens', 'finish_reason')}
        rows.append({k: row[k] for k in (*SOURCE_KEYS, 'image_references', 'input_tokens')} | {'before': before})
    if (len(set(ids)) != 900 or len(rows) != 900 or set(Counter(r['subject'] for r in rows).values()) != {30}
            or sum(r['before']['correct'] for r in rows) != 479 or len(engineering) != 7
            or sum(r['subject'] in engineering for r in rows) != 210):
        raise ValueError('Archived scope or score differs')
    reading = experiments / 'reading-completion-20261117'
    full = experiments / 'scienceqa-scale-full-20261114'
    preference = experiments / 'verified-preference-20261112'
    files = {name: path.read_bytes() for name, path in {
        'experiment.py': HERE / 'experiment.py', 'run.py': reading / 'run.py',
        'run_full.py': full / 'run_full.py', 'run_pilot.py': preference / 'run_pilot.py',
        'scale_sft.py': preference / 'scale_sft.py', 'scorer_source.json': SCORER / 'scorer_source.json',
        'protocol.json': ARCHIVE / 'colab_support/mmmu_val_v8_2048.json',
    }.items()}
    for name, value in (('mmmu.json', rows), ('mmmu-rgb.json', rgb)):
        files[name] = json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
    audit = {'ids': ids, 'engineering_subjects': engineering, 'image_count': len(rgb),
             'archived_baseline': old_manifest['identity'],
             'digest': {name: sha256(raw).hexdigest() for name, raw in files.items()}}
    files['audit.json'] = json.dumps(audit, ensure_ascii=False).encode()
    stream = BytesIO()
    with ZipFile(stream, 'w', compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(files.items()):
            if name.endswith('.py'):
                compile(data, name, 'exec')
            archive.writestr(ZipInfo(name), data, compress_type=ZIP_DEFLATED)
    payload = stream.getvalue()
    digest = sha256(payload).hexdigest()
    driver = files['run_full.py'].decode().split("\nif __name__ == '__main__':", 1)[0]
    chunked = ''.join(f'    {piece!r}\n' for piece in textwrap.wrap(base64.b64encode(payload).decode(), 180))
    start_code = ('# @title L4 · 단일 호출 2048 마무리와 4096 자유 생성\n'
                  f'PAYLOAD_SHA = {digest!r}\nPAYLOAD = (\n{chunked})\n{driver}\n'
                  f'start(base64.b64decode(PAYLOAD, validate=True), PAYLOAD_SHA, job={JOB!r}, '
                  "evaluator='experiment.py', runtime_seconds=8.5*3600, release_delay=240)\n")
    download_code = (f'# @title 검증한 결과 ZIP 다운로드\nfrom google.colab import files\n'
                     f'files.download("/content/{JOB}/recovery.zip")\n')
    intro = ('# Qwen3-VL · 한 번에 생성하는 2048과 4096 비교\n\n'
             '같은 MMMU validation 900문항, P0, 문항별 seed, V8을 쓴다. '
             '2048에서는 1920토큰에 답이 없으면 같은 생성에서 답 머리말을 쓴다. '
             '4096에서는 원본 정책으로 생성한다. 모델 가중치는 동일하다. '
             '토큰 수와 문항별 결과는 실행 중 보존하고 끝나면 런타임을 해제한다.\n')
    cells = [{'cell_type': 'markdown', 'id': 'intro', 'metadata': {}, 'source': intro.splitlines(True)}]
    for key, source in (('run', start_code), ('download', download_code)):
        compile(source, key, 'exec')
        cells.append({'cell_type': 'code', 'id': key, 'metadata': {'cellView': 'form'},
                      'execution_count': None, 'outputs': [], 'source': source.splitlines(True)})
    write(HERE / NOTEBOOK, {'nbformat': 4, 'nbformat_minor': 5, 'cells': cells,
                           'metadata': {'accelerator': 'GPU', 'colab': {'gpuType': 'L4', 'provenance': []},
                                        'kernelspec': {'name': 'python3', 'display_name': 'Python 3',
                                                       'language': 'python'}}})
    print(JOB, digest, len(payload), 'questions', len(rows), 'archived RGB images', len(rgb))


def evaluate(source, repo, out):
    import gzip
    import os
    from importlib.metadata import version
    import torch
    from transformers import AutoConfig, AutoProcessor
    from mmdl.evaluation.final_answer_parser_v8 import score_response
    from mmdl.runtime.artifacts import digest
    from run import mmmu_prompts, paired, request_settings
    from run_full import SCORE_FIELDS, emit, packet, read, sha, write
    import run_pilot as pilot

    if torch.cuda.device_count() != 1 or 'L4' not in torch.cuda.get_device_name(0) or not torch.cuda.is_bf16_supported():
        raise ValueError('Expected one NVIDIA L4 with BF16')
    if 'VLLM_BATCH_INVARIANT' in os.environ:
        raise ValueError('Batch-invariant setting is unsupported by the pinned vLLM')
    os.environ['VLLM_ENABLE_V1_MULTIPROCESSING'] = '0'
    preflight = read(source / 'audit.json')
    if any(sha(source / filename) != expected for filename, expected in preflight['digest'].items()):
        raise ValueError('Input bundle hash mismatch')
    scorer = read(source / 'scorer_source.json')
    for entry in scorer['files']:
        if sha(repo / entry['path']) != entry['sha256']:
            raise ValueError(f"Unexpected V8 source: {entry['path']}")
    protocol = read(source / 'protocol.json')
    path = Path(read(out / 'setup/locations.json')[pilot.MODEL]['snapshot'])
    if path.name != pilot.REVISION or protocol['parser'] != pilot.PARSER or protocol['generation']['max_new_tokens'] != 2048:
        raise ValueError('Unexpected model, parser or original output budget')
    processor = AutoProcessor.from_pretrained(path, use_fast=True, local_files_only=True)
    config = AutoConfig.from_pretrained(path, local_files_only=True)
    size = {'shortest_edge': protocol['image']['min_pixels'], 'longest_edge': protocol['image']['max_pixels']}
    processor.image_processor.size = size
    rows, prompts = mmmu_prompts(source, out, processor, config)
    ids = preflight['ids']
    if ([r['id'] for r in rows] != ids or len(set(ids)) != 900
            or max(r['input_tokens'] for r in rows) + ARMS[LONG] > CONTEXT):
        raise ValueError('Evaluation scope does not match the frozen archive')
    cue_ids = processor.tokenizer.encode(CUE, add_special_tokens=False)
    if decode(processor.tokenizer, cue_ids) != CUE or not 0 < len(cue_ids) < 128:
        raise ValueError('The tokenizer cannot represent the exact final cue')
    packet(out, 'source', {'ids': ids, 'engineering_subjects': preflight['engineering_subjects'],
                           'scorer_sha256': scorer['scoring_sha256'], 'input_bundle': preflight['digest'],
                           'image_count': preflight['image_count'], 'protocol': protocol,
                           'batch': BATCH, 'window': WINDOW, 'context': CONTEXT, 'cue_ids': cue_ids})
    emit('ENGINE_SETUP', {'max_num_seqs': BATCH, 'queue_window': WINDOW, 'context': CONTEXT, 'caps': ARMS})
    llm = pilot.engine(path, {'size': size, 'do_resize': False}, BATCH, CONTEXT,
                       max(len(p['multi_modal_data']['image']) for p in prompts),
                       logits_processors=['experiment:FinishCue'])

    def cue_settings(row, boundary):
        return {'ids': cue_ids, 'boundary': boundary, 'question_type': row['question_type'],
                'options': row['options'], 'question': row['question']}

    def parameters(row, arm):
        params = request_settings(protocol, row['seed'], ARMS[arm])
        if arm == SHORT:
            params.extra_args = {'finish_cue': cue_settings(row, BOUNDARY)}
        return params

    def check_smoke():
        from vllm import SamplingParams

        test = {'question_type': 'open', 'options': [], 'question': 'Count from one to twenty.'}
        text = 'Count from one to twenty with spaces, without explanation.'
        plans = [{'finish_cue': cue_settings(test, 4)}, None]
        params = [SamplingParams(seed=pilot.SEED, max_tokens=24, min_tokens=12, temperature=0.7,
                                 top_k=20, top_p=0.8, n=1, extra_args=plan) for plan in plans]
        pair = llm.generate([text, text], params, use_tqdm=False)
        forced, control = (result.outputs[0].token_ids for result in pair)
        if (list(forced[4:4+len(cue_ids)]) != cue_ids
                or list(control[4:4+len(cue_ids)]) == cue_ids or any(not r.finished for r in pair)):
            raise ValueError('GPU smoke could not prove the forced cue is isolated to its enabled request')
        emit('SINGLE_CALL_SMOKE_PASS', {'forced_at': 4, 'cue_tokens': len(cue_ids), 'same_prompt': True,
                                       'control_followed_own_tokens': True})
    check_smoke()

    def score(row, raw, reason):
        return score_response(raw, row['question_type'], row['options'], row['answer'], reason,
                              question=row['question'])

    def checked_outputs(start, arm):
        stop = min(start + WINDOW, len(rows))
        group = rows[start:stop]
        tick = time.monotonic()
        outputs = llm.generate(prompts[start:stop], [parameters(r, arm) for r in group], use_tqdm=False)
        elapsed = time.monotonic() - tick
        checked = []
        for row, output in zip(group, outputs, strict=True):
            result, = output.outputs
            tokens = list(result.token_ids)
            reason = result.finish_reason
            if (not output.finished or not 0 < len(tokens) <= ARMS[arm] or reason not in ('stop', 'length')
                    or digest(list(output.prompt_token_ids)) != row['actual_engine_prompt_token_ids_sha256']
                    or len(output.prompt_token_ids) + ARMS[arm] > CONTEXT):
                raise ValueError(f'{arm} output or original input verification failed: {row["id"]}')
            route = 'plain'
            if arm == SHORT:
                route = 'terminated_at_or_before_boundary'
                if len(tokens) > BOUNDARY:
                    explicit = has_explicit_answer(decode(processor.tokenizer, tokens[:BOUNDARY]),
                                                   row['question_type'], row['options'], row['question'])
                    route = 'explicit_answer_present' if explicit else 'forced_cue'
                    if not explicit and tokens[BOUNDARY:BOUNDARY+len(cue_ids)] != cue_ids:
                        raise ValueError(f'Forced cue missing at token 1920: {row["id"]}')
            result_row = {'raw_response': result.text, 'finish_reason': reason, 'stop_reason': result.stop_reason,
                          'generated_tokens': len(tokens), 'route': route, 'request_id': output.request_id,
                          **score(row, result.text, reason)}
            checked.append((result_row, tokens))
        return checked, elapsed

    def compare(ids, a, b):
        result = paired(ids, a, b)
        group_sizes = {key: len(group) for key, group in result['groups'].items()}
        return {k: v for k,v in result.items() if k != 'groups'} | {'group_sizes': group_sizes}

    def metrics(scores, cap):
        tokens = [r['generated_tokens'] for r in scores]
        return {'n': len(scores), 'correct': sum(r['correct'] for r in scores),
                'no_parse': sum(r['parse_status'] != 'PARSED' for r in scores),
                'hit_cap': sum(num == cap for num in tokens), 'total_tokens': sum(tokens),
                'mean_tokens': mean(tokens), 'median_tokens': median(tokens)}

    batches, raw_hashes, times = {}, {}, Counter()
    requests = {arm: set() for arm in ARMS}
    routes = Counter()
    verified = 0
    raw_dir = out / 'recovery'
    raw_dir.mkdir(exist_ok=True)
    start_time = time.monotonic()
    log_fields = ('correct', 'parse_status', 'parsed_answer', 'generated_tokens', 'finish_reason', 'route')
    for start in range(0, 900, WINDOW):
        window = rows[start:start + WINDOW]
        order = (SHORT, LONG) if (start // WINDOW) % 2 == 0 else (LONG, SHORT)
        outputs = {}
        for arm in order:
            outputs[arm], elapsed = checked_outputs(start, arm)
            times[arm] += elapsed
        compact, raw_rows = [], []
        for row, (short, a), (long, b) in zip(window, outputs[SHORT], outputs[LONG], strict=True):
            for arm, result in ((SHORT, short), (LONG, long)):
                if result['request_id'] in requests[arm]:
                    raise ValueError(f'Duplicate request: {arm} {row["id"]}')
                requests[arm].add(result['request_id'])
            prefix_text = decode(processor.tokenizer, b[:2048])
            prefix_reason = long['finish_reason'] if len(b) <= 2048 else 'length'
            prefix = score(row, prefix_text, prefix_reason) | {
                'raw_response': prefix_text, 'generated_tokens': min(2048, len(b)), 'finish_reason': prefix_reason}
            first = min(BOUNDARY, len(a), len(b))
            record = {k: row[k] for k in ('id', 'subject', 'seed', 'input_sha256',
                                           'actual_engine_prompt_token_ids_sha256')}
            record |= {SHORT: short, LONG: long, PREFIX: prefix, BASELINE: row['before'],
                       'shared_prefix_checked_tokens': first, 'shared_prefix_equal': a[:first] == b[:first]}
            raw_rows.append(record)
            item = {k: record[k] for k in ('id', 'shared_prefix_equal')}
            for arm in (SHORT, LONG, PREFIX):
                item[arm] = [record[arm].get(k) for k in log_fields]
            compact.append(item)
            routes[short['route']] += 1
        sequence = start // WINDOW + 1
        raw_path = raw_dir / f'raw-paired-{sequence:03d}.json.gz'
        raw_bytes = json.dumps(raw_rows, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
        with raw_path.open('xb') as stream:
            stream.write(gzip.compress(raw_bytes, compresslevel=6, mtime=0))
        raw_hashes[raw_path.name] = sha(raw_path)
        verified += len(compact)
        name = f'rows-paired-{sequence:03d}'
        batches[name] = packet(out, name, compact)
        emit('SINGLE_CALL_PROGRESS', {'n_per_arm': verified, 'target_per_arm': 900,
                                      'arm_seconds': dict(times), 'recent_order': order, 'routes': dict(routes)})

    joined = []
    for name, expected in raw_hashes.items():
        raw_path = raw_dir / name
        if sha(raw_path) != expected:
            raise ValueError(f'Raw result integrity mismatch: {name}')
        joined.extend(json.loads(gzip.decompress(raw_path.read_bytes())))
    if [r['id'] for r in joined] != ids or any(len(req) != 900 for req in requests.values()) or requests[SHORT] & requests[LONG]:
        raise ValueError('Missing, duplicated or reordered evaluation records')
    for row, record in zip(rows, joined, strict=True):
        if any(record[k] != row[k] for k in ('id', 'seed', 'input_sha256', 'actual_engine_prompt_token_ids_sha256')):
            raise ValueError(f'Input identity changed: {row["id"]}')
        for arm in (SHORT, LONG, PREFIX):
            result = record[arm]
            regrade = score(row, result['raw_response'], result['finish_reason'])
            if any(result[k] != regrade[k] for k in SCORE_FIELDS):
                raise ValueError(f'V8 rescore mismatch: {arm} {row["id"]}')

    def aggregate(group):
        group_ids = [r['id'] for r in group]
        scores = {arm: [r[arm] for r in group] for arm in (BASELINE, SHORT, LONG, PREFIX)}
        caps = ARMS | {BASELINE: 2048, PREFIX: 2048}
        comparisons = ((SHORT, LONG), (BASELINE, SHORT), (BASELINE, LONG), (PREFIX, LONG), (PREFIX, SHORT))
        return {'scores': {arm: metrics(values, caps[arm]) for arm, values in scores.items()},
                'pairs': {f'{a}_to_{b}': compare(group_ids, scores[a], scores[b]) for a,b in comparisons}}

    engine = [r for r in joined if r['subject'] in preflight['engineering_subjects']]
    forced = [r for r in joined if r[SHORT]['route'] == 'forced_cue']
    examples = sorted((r for r in forced if r[SHORT]['correct'] != r[LONG]['correct']),
                      key=lambda r: (not r['subject'] in preflight['engineering_subjects'], r['id']))
    selected = [r for r in examples if r[SHORT]['correct']][:6] + [r for r in examples if r[LONG]['correct']][:6]
    example_records = [{k: r[k] for k in ('id', 'subject')} |
                       {arm: r[arm] | {'raw_response': r[arm]['raw_response'][-1800:]} for arm in ARMS}
                       for r in selected]
    summary = {'overall': aggregate(joined), 'engineering': aggregate(engine),
               'by_subject': {name: aggregate([r for r in joined if r['subject'] == name])
                              for name in protocol['dataset']['subjects']},
               'forced_only': aggregate(forced) if forced else None,
               'generation_seconds': dict(times), 'paired_wall_seconds': time.monotonic() - start_time,
               'routes': dict(routes), 'raw_hashes': raw_hashes, 'result_packets': batches,
               'compact_fields': list(log_fields), 'examples': example_records,
               'verification': {'ids': ids, 'unique_requests_per_arm': {a: len(s) for a,s in requests.items()},
                                'input_hashes_verified': 1800, 'independent_v8_rescores': 2700,
                                'equal_prefixes': sum(r['shared_prefix_equal'] for r in joined),
                                'shared_prefix_comparison_cap': BOUNDARY},
               'environment': {package: version(package) for package in ('torch', 'vllm', 'transformers',
                                                                           'qwen-vl-utils', 'pillow')},
               'scorer_sha256': scorer['scoring_sha256'], 'engine_seed': pilot.SEED,
               'batch': BATCH, 'context': CONTEXT, 'window': WINDOW, 'mp0': True,
               'cue_boundary': BOUNDARY, 'cue_tokens': len(cue_ids)}
    if summary['overall']['scores'][BASELINE]['correct'] != 479:
        raise ValueError('Archived comparison score changed')
    write(out / 'verified.json', summary)
    packet(out, 'verified', summary)
    emit('SINGLE_CALL_COMPLETE', {'scores': summary['overall']['scores'], 'arm_seconds': dict(times),
                                  'forced': len(forced), 'n_per_arm': 900})


if __name__ == '__main__':
    if sys.argv[1:] == ['build']:
        build()
    else:
        evaluate(*map(Path, sys.argv[1:]))
